export interface CartItem {
  id: string;
  name: string;
  price: number;
  image: string;
  color: string;
  quantity: number;
}

export interface Review {
  id: string;
  author: string;
  date: string;
  rating: number;
  comment: string;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  hoverImage?: string;
  category: string;
  color: string;
  colorLabel: string;
  badge?: string;
  soldOut?: boolean;
  description: string;
  rating: number;
  reviews: number;
  sold: number;
}

export const PRODUCTS: Product[] = [
{
  id: 'p1',
  name: 'Bolsa Azul Royal com Alça de Madeira',
  price: 189,
  image: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.43_-_Copia-1787246473243.jpeg",
  hoverImage: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.43_-_Copia-1787246473243.jpeg",
  category: 'Bolsa',
  color: 'colorido',
  colorLabel: 'Azul Royal',
  badge: 'Mais Vendida',
  description: 'Sofisticação e charme em cada ponto! Bolsa de crochê em azul royal vibrante com alça de madeira e tiracolo removível — a peça que transforma qualquer look do dia a dia em um statement de estilo artesanal único.',
  rating: 4.9,
  reviews: 47,
  sold: 134
},
{
  id: 'p2',
  name: 'Kit Cestinhas de Crochê Trio Candy',
  price: 215,
  originalPrice: 259,
  image: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.38_-_Copia-1787234370016.jpeg",
  category: 'Kit',
  color: 'colorido',
  colorLabel: 'Rosa/Tiffany/Cinza',
  badge: 'Promoção',
  description: 'Organização com muito estilo! Kit com 3 cestinhas de crochê nas cores rosa, tiffany e cinza — perfeitas para organizar bijuterias, maquiagem ou decorar qualquer cantinho da sua casa com delicadeza artesanal.',
  rating: 4.8,
  reviews: 32,
  sold: 89
},
{
  id: 'p3',
  name: 'Bolsa Hobo Vinho com Detalhes em Couro',
  price: 239,
  image: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.40_-_Copia-1787234370036.jpeg",
  category: 'Hobo',
  color: 'neutro',
  colorLabel: 'Vinho',
  description: 'Elegância que se carrega no ombro! Bolsa hobo em crochê vinho profundo com detalhes em couro que elevam o acabamento artesanal a outro nível — espaçosa, sofisticada e feita com amor para mulheres que têm estilo.',
  rating: 4.9,
  reviews: 28,
  sold: 76
},
{
  id: 'p4',
  name: 'Bolsa Bucket Verde Escuro com Corrente Prata',
  price: 229,
  image: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.42-1787234470292.jpeg",
  hoverImage: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.42-1787234470292.jpeg",
  category: 'Bucket',
  color: 'colorido',
  colorLabel: 'Verde Escuro',
  badge: 'Destaque',
  description: 'Atitude e sofisticação em cada detalhe! Bolsa bucket em crochê verde escuro com corrente prata dourada e contas de madeira que adicionam um toque boho-chic irresistível — a peça que eleva qualquer look ao próximo nível.',
  rating: 4.9,
  reviews: 22,
  sold: 61
},
{
  id: 'p5',
  name: 'Bolsa Azul Marinho com Painel de Palha',
  price: 249,
  image: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.43__1_-1787234601865.jpeg",
  hoverImage: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.43__1_-1787234601865.jpeg",
  category: 'Bolsa',
  color: 'colorido',
  colorLabel: 'Azul Marinho',
  badge: 'Nova',
  description: 'Mar e elegância em uma só peça! Bolsa em azul marinho profundo com painel de palha natural e alça de madeira — uma combinação única que mistura o rústico e o refinado para criar um acessório verdadeiramente especial.',
  rating: 4.8,
  reviews: 18,
  sold: 45
},
{
  id: 'p6',
  name: 'Bolsa Hobo Cinza Grafite com Detalhes em Couro',
  price: 259,
  image: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.44__1_-1787234618405.jpeg",
  hoverImage: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.44__1_-1787234618405.jpeg",
  category: 'Hobo',
  color: 'neutro',
  colorLabel: 'Cinza Grafite',
  badge: 'Exclusiva',
  description: 'Minimalismo poderoso! Bolsa hobo em crochê cinza grafite com acabamentos em couro que transmitem modernidade e requinte — versátil para o trabalho, passeio ou jantar especial, sempre com aquele toque artesanal único.',
  rating: 5.0,
  reviews: 15,
  sold: 38
},
{
  id: 'p7',
  name: 'Bolsa Baguete Preta com Alça Trançada',
  price: 219,
  image: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.44__2_-1787234631420.jpeg",
  hoverImage: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.44__2_-1787234631420.jpeg",
  category: 'Baguete',
  color: 'neutro',
  colorLabel: 'Preto',
  description: 'O clássico reinventado! Bolsa baguete em crochê preto com alça trançada artesanal e argolas prateadas — elegante, compacta e cheia de personalidade para quem quer um acessório que conta uma história.',
  rating: 4.9,
  reviews: 31,
  sold: 82
},
{
  id: 'p8',
  name: 'Bolsa Tote Areia com Textura em Relevo',
  price: 235,
  image: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.44__3_-1787234646622.jpeg",
  hoverImage: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.44__3_-1787234646622.jpeg",
  category: 'Tote',
  color: 'neutro',
  colorLabel: 'Areia/Bege',
  badge: 'Mais Vendida',
  description: 'Leveza e sofisticação para o dia a dia! Bolsa tote em crochê areia/bege com textura em relevo e alça dupla resistente — espaçosa o suficiente para carregar tudo que você precisa com muito estilo e delicadeza artesanal.',
  rating: 4.8,
  reviews: 39,
  sold: 103
},
{
  id: 'p9',
  name: 'Bolsa Redonda Azul com Alça Caramelo e Tassel',
  price: 269,
  image: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.44-1787234790136.jpeg",
  hoverImage: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.44-1787234790136.jpeg",
  category: 'Bolsa',
  color: 'colorido',
  colorLabel: 'Azul/Caramelo',
  badge: 'Nova',
  description: 'Redonda, charmosa e irresistível! Bolsa de crochê em azul vibrante com alças de couro caramelo e pingente tassel artesanal — uma peça circular que foge do comum e transforma qualquer look em obra de arte. Feita à mão com amor e muito estilo.',
  rating: 5.0,
  reviews: 12,
  sold: 29
},
{
  id: 'p10',
  name: 'Destaque Editorial — Elegante e Atemporal',
  price: 299,
  image: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.45__1_-1787234803981.jpeg",
  hoverImage: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.45__1_-1787234803981.jpeg",
  category: 'Bolsa',
  color: 'neutro',
  colorLabel: 'Exclusiva',
  badge: 'Exclusiva',
  description: 'A peça que toda mulher merece! Criação exclusiva da Lilian Artesanato — elegante, atemporal e feita com os melhores fios. Uma bolsa que conta a história de quem a carrega e nunca sai de moda. Encomende a sua e seja única.',
  rating: 5.0,
  reviews: 8,
  sold: 17
},
{
  id: 'p11',
  name: 'Bolsa Quadrada Granny Square com Alça de Bambu',
  price: 245,
  originalPrice: 289,
  image: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.45__2_-1787234815625.jpeg",
  hoverImage: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.45__2_-1787234815625.jpeg",
  category: 'Bolsa',
  color: 'colorido',
  colorLabel: 'Multicolorida',
  badge: 'Promoção',
  description: 'Alegria em cada quadradinho! Bolsa quadrada em crochê granny square multicolorido com alça de bambu natural e corrente dourada — uma explosão de cor e personalidade para quem ama o estilo boho-chic. Cada peça é única, assim como você!',
  rating: 4.9,
  reviews: 21,
  sold: 54
},
{
  id: 'p12',
  name: 'Chinelo Customizado com Flores de Crochê',
  price: 89,
  image: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.45__3_-1787234832651.jpeg",
  hoverImage: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.45__3_-1787234832651.jpeg",
  category: 'Acessório',
  color: 'colorido',
  colorLabel: 'Colorido',
  badge: 'Destaque',
  description: 'Seus pés merecem arte! Chinelo customizado com flores de crochê feitas à mão — delicadas, coloridas e cheias de charme. Perfeito para o dia a dia, praia ou presentear alguém especial. Conforto e beleza artesanal do jeito que só a Lilian faz!',
  rating: 4.8,
  reviews: 35,
  sold: 98
},
{
  id: 'p13',
  name: 'Bolsa Tote Geométrica com Pingentes de Madeira',
  price: 279,
  image: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.45__4_-1787234844776.jpeg",
  hoverImage: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.45__4_-1787234844776.jpeg",
  category: 'Tote',
  color: 'colorido',
  colorLabel: 'Multicolorida',
  badge: 'Nova',
  description: 'Arte geométrica que você carrega! Bolsa tote multicolorida com padrão geométrico em crochê e pingentes de madeira artesanais — espaçosa, resistente e cheia de personalidade. Uma peça que mistura tradição e modernidade com maestria única.',
  rating: 4.9,
  reviews: 14,
  sold: 33
},
{
  id: 'p14',
  name: 'Conjunto Colar Multicamadas com Pérolas & Brincos Grafite',
  price: 149,
  image: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.45-1787234996588.jpeg",
  hoverImage: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.45-1787234996588.jpeg",
  category: 'Acessório',
  color: 'neutro',
  colorLabel: 'Dourado/Bronze/Branco',
  badge: 'Nova',
  description: 'Elegância em camadas! Conjunto exclusivo com colar multicamadas em crochê com pérolas douradas, bronze e branco — sofisticado e versátil — acompanhado de brincos de crochê grafite que equilibram o look com modernidade. Perfeito para ocasiões especiais ou para elevar o dia a dia com arte feita à mão.',
  rating: 4.9,
  reviews: 18,
  sold: 42
},
{
  id: 'p15',
  name: 'Conjunto Vinho/Uva — Colar com Ágata, Brincos Flor & Pulseiras',
  price: 189,
  originalPrice: 229,
  image: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.46__1_-1787235008310.jpeg",
  hoverImage: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.46__1_-1787235008310.jpeg",
  category: 'Acessório',
  color: 'colorido',
  colorLabel: 'Vinho/Uva',
  badge: 'Promoção',
  description: 'O conjunto que toda mulher apaixonada por crochê precisa! Colar artesanal em tons vinho e uva com pedra de ágata natural no centro — poderosa e elegante — acompanhado de brincos flor delicados e pulseiras largas que completam o visual com muito charme boho. Uma coleção completa de joias de crochê feitas com amor.',
  rating: 5.0,
  reviews: 24,
  sold: 58
},
{
  id: 'p16',
  name: 'Vestido Longo de Crochê Off-White Rendado Boho',
  price: 389,
  image: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.46__2_-1787235020452.jpeg",
  hoverImage: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.46__2_-1787235020452.jpeg",
  category: 'Roupa',
  color: 'neutro',
  colorLabel: 'Off-White',
  badge: 'Exclusiva',
  description: 'A peça dos sonhos para quem ama o estilo boho! Vestido longo de crochê off-white com rendado artesanal delicado — elegante, feminino e atemporal. Cada ponto é feito à mão com fios de alta qualidade, criando uma textura única que valoriza a silhueta. Ideal para casamentos na praia, festas ao ar livre ou para quem quer se sentir uma deusa todos os dias.',
  rating: 5.0,
  reviews: 11,
  sold: 19
},
{
  id: 'p17',
  name: 'Bolsa Clutch Rose Gold com Alça de Bambu e Corrente Dourada',
  price: 199,
  image: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.46__3_-1787235032682.jpeg",
  hoverImage: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.46__3_-1787235032682.jpeg",
  category: 'Clutch',
  color: 'colorido',
  colorLabel: 'Rose Gold',
  badge: 'Destaque',
  description: 'Glamour artesanal na palma da mão! Clutch de crochê em rose gold com alça de bambu natural e corrente dourada removível — a combinação perfeita de delicadeza e sofisticação. Compacta e estilosa, é a bolsa ideal para festas, jantares e eventos especiais onde você quer arrasar com um toque único e exclusivo.',
  rating: 4.9,
  reviews: 27,
  sold: 63
},
{
  id: 'p18',
  name: 'Bolsa Tiracolo Caramelo/Cobre com Alça de Madeira e Corrente Dourada',
  price: 259,
  image: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.46-1787235045998.jpeg",
  hoverImage: "/assets/images/WhatsApp_Image_2026-08-14_at_18.28.46-1787235045998.jpeg",
  category: 'Tiracolo',
  color: 'neutro',
  colorLabel: 'Caramelo/Cobre',
  badge: 'Nova',
  description: 'Calor e elegância em cada detalhe! Bolsa tiracolo em crochê nas tonalidades caramelo e cobre com alça de madeira amarela artesanal e corrente dourada — uma peça que aquece o visual e traz sofisticação natural ao look. Versátil para o dia a dia ou para ocasiões especiais, é o acessório que toda mulher de bom gosto precisa ter.',
  rating: 4.8,
  reviews: 16,
  sold: 37
},
{
  id: 'p19',
  name: 'Chapéu de Praia de Crochê Caramelo',
  price: 129,
  image: "/assets/images/WhatsApp_Image_2026-08-20_at_16.01.22__1_-1787253786669.jpeg",
  hoverImage: "/assets/images/WhatsApp_Image_2026-08-20_at_16.01.22__1_-1787253786669.jpeg",
  category: 'Acessório',
  color: 'neutro',
  colorLabel: 'Caramelo',
  badge: 'Nova',
  description: 'Verão com muito estilo e charme artesanal! Chapéu de praia de crochê na cor caramelo quente — elegante, leve e feito à mão com fios de alta qualidade. A aba generosa protege do sol enquanto você arrasa no look praiano. Uma peça única que combina com tudo e transforma qualquer visual em um statement de moda artesanal irresistível.',
  rating: 4.9,
  reviews: 20,
  sold: 52
},
{
  id: 'p20',
  name: 'Vestido Longo Granny Square Multicolorido',
  price: 459,
  image: "/assets/images/WhatsApp_Image_2026-08-20_at_16.01.22__2_-1787253799934.jpeg",
  hoverImage: "/assets/images/WhatsApp_Image_2026-08-20_at_16.01.22-1787253815338.jpeg",
  category: 'Roupa',
  color: 'colorido',
  colorLabel: 'Multicolorido',
  badge: 'Exclusiva',
  description: 'Uma explosão de cor e arte em cada quadradinho! Vestido longo de crochê em ponto granny square multicolorido — vibrante, único e cheio de personalidade. Cada quadrado é feito à mão com fios coloridos que criam um mosaico de alegria e estilo boho-chic. Caimento fluido e elegante que valoriza a silhueta. A peça que toda mulher apaixonada por crochê sonha em ter!',
  rating: 5.0,
  reviews: 18,
  sold: 42
},
{
  id: 'p21',
  name: 'Bolsa Quadrada Granny Square Laranja com Alça de Madeira',
  price: 249,
  image: "/assets/images/WhatsApp_Image_2026-08-20_at_16.01.25__1_-1787253829539.jpeg",
  hoverImage: "/assets/images/WhatsApp_Image_2026-08-20_at_16.01.25__1_-1787253829539.jpeg",
  category: 'Bolsa',
  color: 'colorido',
  colorLabel: 'Laranja/Multicolorido',
  badge: 'Destaque',
  description: 'Alegria, cor e artesanato em uma só peça! Bolsa quadrada de crochê em ponto granny square com fundo laranja vibrante e flores coloridas que encantam à primeira vista. A alça de madeira natural dá um toque boho-chic sofisticado e artesanal. Espaçosa, resistente e completamente única — porque cada flor é feita à mão com muito amor e capricho.',
  rating: 4.9,
  reviews: 16,
  sold: 34
},
{
  id: 'p22',
  name: 'Bolsa Tote Verde Militar com Estrela Off-White e Alça de Madeira',
  price: 229,
  image: "/assets/images/WhatsApp_Image_2026-08-20_at_16.01.25__2_-1787253846013.jpeg",
  hoverImage: "/assets/images/WhatsApp_Image_2026-08-20_at_16.01.25__2_-1787253846013.jpeg",
  category: 'Tote',
  color: 'colorido',
  colorLabel: 'Verde Militar',
  badge: 'Nova',
  description: 'Estilo, atitude e artesanato em uma bolsa incrível! Tote de crochê em verde militar com estrela off-white bordada à mão no centro — uma combinação moderna e cheia de personalidade. A alça de madeira natural eleva o acabamento artesanal e garante resistência para o dia a dia. Espaçosa e versátil, é a bolsa perfeita para quem quer se destacar com originalidade.',
  rating: 4.9,
  reviews: 14,
  sold: 30
},
{
  id: 'p23',
  name: 'Vestido Longo Granny Square Multicolorido — Foto Vestindo',
  price: 489,
  image: "/assets/images/WhatsApp_Image_2026-08-20_at_16.01.22-1787254164278.jpeg",
  hoverImage: "/assets/images/WhatsApp_Image_2026-08-20_at_16.01.22-1787254164278.jpeg",
  category: 'Roupa',
  color: 'colorido',
  colorLabel: 'Multicolorido',
  badge: 'Exclusiva',
  description: '✨ A peça que para o tempo! Vestido longo de crochê em ponto granny square multicolorido — cada quadradinho feito à mão com fios vibrantes que criam um mosaico de cor e alegria. Caimento fluido e elegante que valoriza a silhueta em qualquer ocasião. Do casual ao especial, este vestido é uma declaração de amor ao artesanato. Peça única, feita com alma!',
  rating: 5.0,
  reviews: 12,
  sold: 28
},
{
  id: 'p24',
  name: 'Vestido Midi Listrado Tons Terrosos com Alça Única',
  price: 379,
  image: "/assets/images/WhatsApp_Image_2026-08-20_at_16.01.25-1787254176832.jpeg",
  hoverImage: "/assets/images/WhatsApp_Image_2026-08-20_at_16.01.25-1787254176832.jpeg",
  category: 'Roupa',
  color: 'neutro',
  colorLabel: 'Tons Terrosos',
  badge: 'Nova',
  description: '🌿 Sofisticação boho em cada fio! Vestido midi de crochê listrado em tons terrosos quentes — caramelo, areia e marrom que harmonizam com a natureza e com o seu estilo. A alça única assimétrica dá um toque moderno e sensual ao design artesanal. Leve, elegante e completamente feito à mão. Para a mulher que carrega arte onde quer que vá!',
  rating: 4.9,
  reviews: 9,
  sold: 21
},
{
  id: 'p25',
  name: 'Bolsa Meia-Lua Branca com Corrente Dourada e Pérolas',
  price: 299,
  image: "/assets/images/Captura_de_tela_2026-08-20_162115-1787254189859.png",
  hoverImage: "/assets/images/Captura_de_tela_2026-08-20_162115-1787254189859.png",
  category: 'Bolsa',
  color: 'neutro',
  colorLabel: 'Branco/Dourado',
  badge: 'Destaque',
  description: '💎 Elegância pura em formato de meia-lua! Bolsa de crochê branca com corrente dourada e detalhes de pérolas que elevam o acabamento artesanal ao luxo. O formato meia-lua é tendência e a combinação branco + dourado + pérolas é atemporal e sofisticada. Perfeita para festas, jantares ou para transformar qualquer look do dia em algo especial. Arte que se carrega!',
  rating: 5.0,
  reviews: 15,
  sold: 38
},
{
  id: 'p26',
  name: 'Bolsa Tote Rose/Nude com Flores em Crochê e Alças Duplas',
  price: 269,
  image: "/assets/images/Captura_de_tela_2026-08-20_162134-1787254199079.png",
  hoverImage: "/assets/images/Captura_de_tela_2026-08-20_162134-1787254199079.png",
  category: 'Tote',
  color: 'neutro',
  colorLabel: 'Rose/Nude',
  badge: 'Mais Vendida',
  description: '🌸 Delicadeza e charme em cada florzinha! Bolsa tote de crochê em tons rose e nude com flores artesanais aplicadas à mão — um jardim que você carrega com você. As alças duplas garantem conforto e praticidade para o dia a dia. Espaçosa, resistente e irresistivelmente feminina. Para quem ama o artesanato com toda a sua delicadeza e personalidade única!',
  rating: 4.9,
  reviews: 22,
  sold: 55
},
];


export const formatBRL = (value: number): string => {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
};

export const PRODUCT_REVIEWS: Record<string, Review[]> = {
  p1: [
    { id: 'r1-1', author: 'Fernanda Oliveira', date: '12/07/2026', rating: 5, comment: 'Simplesmente apaixonada! A qualidade do crochê é impecável, cada ponto perfeito. A alça de madeira dá um charme único e a bolsa é ainda mais linda pessoalmente. Recebi vários elogios!' },
    { id: 'r1-2', author: 'Camila Souza', date: '28/06/2026', rating: 5, comment: 'O acabamento artesanal é de outro nível. Dá pra ver o cuidado em cada detalhe. O azul royal é vibrante e não desbotou nada após algumas semanas de uso. Amei demais!' },
    { id: 'r1-3', author: 'Juliana Martins', date: '15/06/2026', rating: 5, comment: 'Melhor compra que fiz! A textura do crochê é firme e bem trabalhada. O tiracolo removível é super prático. A Lilian caprichou no design — é uma peça de arte!' },
    { id: 'r1-4', author: 'Patrícia Lima', date: '02/06/2026', rating: 4, comment: 'Bolsa linda e bem feita. O crochê é resistente e o design é muito elegante. Só demorou um pouco mais que o esperado para chegar, mas valeu cada dia de espera!' },
  ],
  p2: [
    { id: 'r2-1', author: 'Renata Costa', date: '10/07/2026', rating: 5, comment: 'As cestinhas são uma fofura! A qualidade do crochê é excelente, bem firme e com acabamento perfeito. As cores são exatamente como nas fotos. Já encomendei mais um kit!' },
    { id: 'r2-2', author: 'Aline Ferreira', date: '25/06/2026', rating: 5, comment: 'Presenteei minha mãe e ela adorou! O artesanato é muito bem feito, dá pra ver que cada cestinha foi feita com muito cuidado. As cores candy são deliciosas!' },
    { id: 'r2-3', author: 'Mariana Alves', date: '18/06/2026', rating: 4, comment: 'Muito bonitas e bem acabadas. Uso para organizar maquiagem e ficou lindo na penteadeira. O crochê é bem resistente, não deforma. Recomendo!' },
  ],
  p3: [
    { id: 'r3-1', author: 'Isabela Rocha', date: '08/07/2026', rating: 5, comment: 'A bolsa hobo é simplesmente perfeita! O vinho é profundo e sofisticado, e os detalhes em couro elevam muito o acabamento. A qualidade artesanal é visível em cada ponto.' },
    { id: 'r3-2', author: 'Daniela Nunes', date: '22/06/2026', rating: 5, comment: 'Comprei para usar no trabalho e recebo elogios todos os dias. O crochê é muito bem trabalhado e o couro é de qualidade. Uma peça que combina elegância e artesanato.' },
    { id: 'r3-3', author: 'Tatiana Gomes', date: '14/06/2026', rating: 5, comment: 'Superou todas as expectativas! O design é único e a execução artesanal é impecável. A bolsa é espaçosa e o acabamento interno também é muito cuidadoso.' },
    { id: 'r3-4', author: 'Luciana Pereira', date: '05/06/2026', rating: 4, comment: 'Muito bem feita e linda! O vinho é lindo e combina com tudo. O crochê é firme e bem estruturado. Entrega rápida e embalagem cuidadosa.' },
  ],
  p4: [
    { id: 'r4-1', author: 'Viviane Santos', date: '11/07/2026', rating: 5, comment: 'A bolsa bucket é incrível! O verde escuro é lindo e a corrente prata dá um toque sofisticado. O crochê é muito bem feito, firme e com textura linda. Amei!' },
    { id: 'r4-2', author: 'Cristina Barbosa', date: '27/06/2026', rating: 5, comment: 'Design arrasador! As contas de madeira são um detalhe que faz toda a diferença. A qualidade artesanal é excepcional — dá pra ver que cada peça é feita com amor.' },
    { id: 'r4-3', author: 'Priscila Mendes', date: '19/06/2026', rating: 4, comment: 'Muito bonita e bem estruturada. O crochê é resistente e o design é muito criativo. Uso como bolsa de trabalho e recebo elogios constantemente.' },
  ],
  p5: [
    { id: 'r5-1', author: 'Adriana Carvalho', date: '09/07/2026', rating: 5, comment: 'A combinação do azul marinho com o painel de palha é simplesmente deslumbrante! O artesanato é de altíssima qualidade e a alça de madeira é muito resistente.' },
    { id: 'r5-2', author: 'Simone Ribeiro', date: '24/06/2026', rating: 5, comment: 'Bolsa nova e já virou minha favorita! O design é único e muito bem executado. O crochê tem uma textura linda e o painel de palha é um diferencial incrível.' },
    { id: 'r5-3', author: 'Elaine Teixeira', date: '16/06/2026', rating: 4, comment: 'Muito bem feita e com um design diferenciado. O azul marinho é lindo e o painel de palha dá um charme rústico muito elegante. Recomendo muito!' },
  ],
  p6: [
    { id: 'r6-1', author: 'Mônica Azevedo', date: '07/07/2026', rating: 5, comment: 'Perfeição em forma de bolsa! O cinza grafite é sofisticado e o acabamento em couro é impecável. O crochê é muito bem trabalhado — uma obra de arte artesanal.' },
    { id: 'r6-2', author: 'Vanessa Correia', date: '21/06/2026', rating: 5, comment: 'Comprei e me apaixonei! O design minimalista é exatamente o que eu queria. A qualidade do crochê é excepcional e o couro é muito bem acabado. Vale cada centavo!' },
    { id: 'r6-3', author: 'Roberta Dias', date: '13/06/2026', rating: 5, comment: 'A bolsa mais linda que já tive! O grafite combina com tudo e o artesanato é de altíssimo nível. Cada detalhe foi pensado com muito cuidado. Nota 10!' },
  ],
  p7: [
    { id: 'r7-1', author: 'Letícia Moreira', date: '10/07/2026', rating: 5, comment: 'A bolsa baguete é um clássico reinventado! O crochê preto é muito bem trabalhado e a alça trançada é um detalhe artesanal lindo. Design elegante e atemporal.' },
    { id: 'r7-2', author: 'Natália Freitas', date: '26/06/2026', rating: 5, comment: 'Simplesmente perfeita para o dia a dia! O acabamento é impecável e o crochê é muito resistente. As argolas prateadas dão um toque moderno ao design clássico.' },
    { id: 'r7-3', author: 'Bianca Pinto', date: '17/06/2026', rating: 4, comment: 'Muito bem feita e com um design muito elegante. O preto combina com tudo e o crochê é de ótima qualidade. Compacta mas com espaço suficiente para o essencial.' },
    { id: 'r7-4', author: 'Larissa Campos', date: '08/06/2026', rating: 5, comment: 'Bolsa linda e com acabamento artesanal impecável! A alça trançada é muito bem feita e resistente. Recebi como presente e fiquei encantada com a qualidade.' },
  ],
  p8: [
    { id: 'r8-1', author: 'Cláudia Nascimento', date: '12/07/2026', rating: 5, comment: 'A bolsa tote é perfeita! A textura em relevo é um diferencial artesanal incrível. O bege/areia é versátil e combina com tudo. Qualidade excepcional em cada detalhe.' },
    { id: 'r8-2', author: 'Flávia Cardoso', date: '28/06/2026', rating: 5, comment: 'Uso diariamente e a qualidade do crochê impressiona! A textura em relevo é linda e o acabamento é muito cuidadoso. Espaçosa e elegante ao mesmo tempo.' },
    { id: 'r8-3', author: 'Andréa Melo', date: '20/06/2026', rating: 4, comment: 'Muito bem feita e com um design sofisticado. A textura em relevo é um detalhe artesanal que faz toda a diferença. Recomendo para quem busca qualidade e estilo.' },
    { id: 'r8-4', author: 'Sônia Vieira', date: '11/06/2026', rating: 5, comment: 'Bolsa linda e muito bem acabada! O crochê é firme e bem estruturado. A textura em relevo é um trabalho artesanal impressionante. Já indiquei para várias amigas!' },
  ],
  p9: [
    { id: 'r9-1', author: 'Giovana Lopes', date: '09/07/2026', rating: 5, comment: 'A bolsa redonda é uma obra de arte! O azul vibrante com as alças caramelo é uma combinação perfeita. O crochê é muito bem trabalhado e o tassel artesanal é um charme.' },
    { id: 'r9-2', author: 'Rafaela Cunha', date: '23/06/2026', rating: 5, comment: 'Comprei e não me arrependo! O design circular é único e muito bem executado. A qualidade artesanal é visível em cada ponto. Recebi muitos elogios!' },
    { id: 'r9-3', author: 'Sabrina Monteiro', date: '15/06/2026', rating: 5, comment: 'Simplesmente apaixonante! O crochê azul com o couro caramelo é uma combinação que só a Lilian faz com tanta maestria. Peça única e de altíssima qualidade.' },
  ],
  p10: [
    { id: 'r10-1', author: 'Alessandra Fonseca', date: '08/07/2026', rating: 5, comment: 'Uma peça editorial de verdade! O design é atemporal e o artesanato é de nível altíssimo. Cada detalhe foi pensado com muito cuidado. Uma bolsa que conta uma história.' },
    { id: 'r10-2', author: 'Margarida Sousa', date: '22/06/2026', rating: 5, comment: 'Exclusividade e qualidade em uma só peça! O crochê é impecável e o design é sofisticado. Vale cada centavo — é uma peça que vai durar para sempre.' },
    { id: 'r10-3', author: 'Tereza Cavalcanti', date: '14/06/2026', rating: 5, comment: 'A bolsa mais especial que já tive! O artesanato é de altíssima qualidade e o design é único. A Lilian é uma artesã excepcional — cada ponto é perfeito.' },
  ],
  p11: [
    { id: 'r11-1', author: 'Beatriz Nogueira', date: '11/07/2026', rating: 5, comment: 'Os granny squares são lindíssimos! O crochê multicolorido é muito bem trabalhado e a alça de bambu é um detalhe artesanal perfeito. Uma explosão de alegria!' },
    { id: 'r11-2', author: 'Carolina Machado', date: '27/06/2026', rating: 4, comment: 'Bolsa linda e cheia de personalidade! O design boho-chic é muito bem executado. O crochê é resistente e as cores são vibrantes. Amei o resultado!' },
    { id: 'r11-3', author: 'Débora Araújo', date: '19/06/2026', rating: 5, comment: 'Cada quadradinho é uma obra de arte! O artesanato é impecável e o design é único. A corrente dourada é um detalhe que eleva muito o acabamento. Nota 10!' },
    { id: 'r11-4', author: 'Elisa Borges', date: '10/06/2026', rating: 5, comment: 'Comprei na promoção e foi um achado! A qualidade do crochê é excepcional e o design multicolorido é lindo. Cada peça é realmente única — adorei!' },
  ],
  p12: [
    { id: 'r12-1', author: 'Fabiana Ramos', date: '10/07/2026', rating: 5, comment: 'As flores de crochê são uma delícia! O artesanato é muito bem feito e as flores são bem fixadas. Uso na praia e recebo elogios de todo mundo. Muito charme!' },
    { id: 'r12-2', author: 'Gabriela Pires', date: '25/06/2026', rating: 5, comment: 'Presenteei minha filha e ela amou! As flores são lindas e bem trabalhadas. O crochê é delicado mas resistente. Um acessório único e muito criativo!' },
    { id: 'r12-3', author: 'Helena Barros', date: '17/06/2026', rating: 4, comment: 'Muito fofo e bem feito! As flores de crochê são um detalhe artesanal que faz toda a diferença. Confortável e estiloso ao mesmo tempo. Recomendo!' },
    { id: 'r12-4', author: 'Ingrid Cavalcante', date: '08/06/2026', rating: 5, comment: 'Arte nos pés! O crochê das flores é muito bem trabalhado e as cores são lindas. Um acessório que transforma qualquer look. A Lilian é muito talentosa!' },
  ],
  p13: [
    { id: 'r13-1', author: 'Joana Silveira', date: '09/07/2026', rating: 5, comment: 'A bolsa tote geométrica é incrível! O padrão em crochê é muito bem executado e os pingentes de madeira são um detalhe artesanal perfeito. Design único e sofisticado.' },
    { id: 'r13-2', author: 'Karina Duarte', date: '24/06/2026', rating: 5, comment: 'Comprei e me apaixonei! O crochê geométrico é muito bem trabalhado e as cores são vibrantes. Os pingentes de madeira são um charme. Espaçosa e linda!' },
    { id: 'r13-3', author: 'Luana Ferraz', date: '16/06/2026', rating: 4, comment: 'Design muito criativo e bem executado! O crochê é resistente e o padrão geométrico é lindo. Os pingentes de madeira são um detalhe artesanal que faz toda a diferença.' },
  ],
  p14: [
    { id: 'r14-1', author: 'Milena Guimarães', date: '08/07/2026', rating: 5, comment: 'O conjunto é simplesmente deslumbrante! As pérolas no crochê são um detalhe artesanal de altíssima qualidade. Os brincos grafite equilibram perfeitamente o look.' },
    { id: 'r14-2', author: 'Nathalia Rezende', date: '22/06/2026', rating: 5, comment: 'Usei em um casamento e fui a mais elogiada! O crochê com pérolas é muito bem trabalhado e o design multicamadas é sofisticado. Arte artesanal de verdade!' },
    { id: 'r14-3', author: 'Olivia Santana', date: '14/06/2026', rating: 4, comment: 'Conjunto muito bem feito e com um design elegante. O crochê é delicado e as pérolas são de boa qualidade. Os brincos são um complemento perfeito.' },
    { id: 'r14-4', author: 'Paula Rodrigues', date: '05/06/2026', rating: 5, comment: 'Joia artesanal de verdade! O crochê com pérolas é impecável e o design é muito sofisticado. Recebi vários elogios e indiquei para todas as minhas amigas.' },
  ],
  p15: [
    { id: 'r15-1', author: 'Quésia Andrade', date: '07/07/2026', rating: 5, comment: 'O conjunto vinho é uma obra de arte! A pedra de ágata no colar é linda e o crochê é muito bem trabalhado. Os brincos flor são delicados e os pulseiras são perfeitas.' },
    { id: 'r15-2', author: 'Regina Batista', date: '21/06/2026', rating: 5, comment: 'Comprei na promoção e foi um presente incrível para mim mesma! O artesanato é de altíssima qualidade e o design boho é lindo. A ágata é uma pedra linda!' },
    { id: 'r15-3', author: 'Sandra Coelho', date: '13/06/2026', rating: 5, comment: 'Conjunto completo e muito bem feito! O crochê vinho é sofisticado e a ágata é um detalhe natural lindo. Os brincos flor são delicados e bem acabados.' },
    { id: 'r15-4', author: 'Tânia Esteves', date: '04/06/2026', rating: 5, comment: 'Simplesmente perfeito! O design boho-chic é muito bem executado e o artesanato é impecável. A combinação vinho/uva é sofisticada e muito elegante.' },
  ],
  p16: [
    { id: 'r16-1', author: 'Úrsula Figueiredo', date: '06/07/2026', rating: 5, comment: 'O vestido é um sonho! O crochê off-white é muito bem trabalhado e o rendado artesanal é de uma delicadeza incrível. Usei em um casamento na praia e fui a mais elogiada!' },
    { id: 'r16-2', author: 'Valéria Henrique', date: '20/06/2026', rating: 5, comment: 'Uma peça exclusiva de verdade! O artesanato é de altíssima qualidade e o design é atemporal. O crochê rendado é muito bem executado — parece uma obra de arte.' },
    { id: 'r16-3', author: 'Wanda Lacerda', date: '12/06/2026', rating: 5, comment: 'Comprei para meu casamento e foi a melhor decisão! O vestido é lindo e o crochê é impecável. Cada ponto foi feito com muito amor e cuidado. Nota 10!' },
  ],
  p17: [
    { id: 'r17-1', author: 'Xênia Marques', date: '09/07/2026', rating: 5, comment: 'A clutch rose gold é um glamour! O crochê é muito bem trabalhado e a alça de bambu é um detalhe artesanal perfeito. A corrente dourada é um charme. Amei!' },
    { id: 'r17-2', author: 'Yara Tavares', date: '24/06/2026', rating: 5, comment: 'Usei em um jantar especial e recebi muitos elogios! O rose gold é lindo e o crochê é muito bem feito. A combinação bambu + corrente dourada é sofisticada.' },
    { id: 'r17-3', author: 'Zélia Pacheco', date: '16/06/2026', rating: 4, comment: 'Clutch linda e bem acabada! O crochê rose gold é delicado e o design é muito elegante. Compacta mas com espaço suficiente. Recomendo para festas!' },
    { id: 'r17-4', author: 'Ana Beatriz Leal', date: '07/06/2026', rating: 5, comment: 'Peça de arte artesanal! O crochê é impecável e o design é muito sofisticado. A alça de bambu é um detalhe natural que equilibra o glamour do rose gold.' },
  ],
  p18: [
    { id: 'r18-1', author: 'Bruna Castelo', date: '08/07/2026', rating: 5, comment: 'A bolsa tiracolo é linda! O caramelo/cobre é uma combinação quente e sofisticada. O crochê é muito bem trabalhado e a alça de madeira é um detalhe artesanal lindo.' },
    { id: 'r18-2', author: 'Cecília Drummond', date: '23/06/2026', rating: 5, comment: 'Comprei e não me arrependo! O design é muito elegante e o artesanato é de altíssima qualidade. A corrente dourada é um detalhe que eleva muito o acabamento.' },
    { id: 'r18-3', author: 'Diana Espíndola', date: '15/06/2026', rating: 4, comment: 'Muito bem feita e com um design sofisticado. O caramelo/cobre é lindo e o crochê é resistente. Versátil para o dia a dia e para ocasiões especiais.' },
  ],
  p19: [
    { id: 'r19-1', author: 'Fernanda Oliveira', date: '10/08/2026', rating: 5, comment: 'Chapéu lindo e perfeito para o verão! O caramelo combina com tudo e o crochê é muito bem feito. Proteção com muito estilo!' },
    { id: 'r19-2', author: 'Gabriela Santos', date: '15/08/2026', rating: 5, comment: 'Amei o chapéu! Elegante, artesanal e com um acabamento impecável. Usei na praia e recebi muitos elogios. Super recomendo!' },
  ],
  p20: [
    { id: 'r20-1', author: 'Helena Moreira', date: '12/08/2026', rating: 5, comment: 'Vestido incrível! As cores do granny square são vibrantes e o caimento é perfeito. Uma peça única que chama atenção em qualquer lugar!' },
    { id: 'r20-2', author: 'Isabela Rocha', date: '16/08/2026', rating: 5, comment: 'Simplesmente apaixonada! O vestido é uma obra de arte. Cada quadradinho colorido é feito com muito capricho. Elegante e cheio de personalidade!' },
  ],
  p21: [
    { id: 'r21-1', author: 'Juliana Ferreira', date: '14/08/2026', rating: 5, comment: 'Bolsa maravilhosa! O laranja é vibrante e as flores coloridas são um charme. A alça de madeira dá um toque artesanal sofisticado. Amei!' },
    { id: 'r21-2', author: 'Karla Mendes', date: '18/08/2026', rating: 5, comment: 'Peça única e cheia de personalidade! O granny square laranja é lindo e o acabamento é impecável. Recebo elogios toda vez que uso!' },
  ],
  p22: [
    { id: 'r22-1', author: 'Larissa Costa', date: '17/08/2026', rating: 5, comment: 'Bolsa tote linda e resistente! O verde militar com a estrela off-white é uma combinação estilosa e moderna. A alça de madeira é um detalhe artesanal perfeito!' },
    { id: 'r22-2', author: 'Mariana Alves', date: '19/08/2026', rating: 5, comment: 'Amei a bolsa! O verde militar é sofisticado e a estrela off-white dá um toque especial. Espaçosa e muito bem feita. Super recomendo!' },
  ],
  p23: [
    { id: 'r23-1', author: 'Natália Vieira', date: '18/08/2026', rating: 5, comment: 'Vestido de tirar o fôlego! Os granny squares multicoloridos são lindíssimos e o caimento é perfeito. Usei em um evento e fui a mais elogiada da noite!' },
    { id: 'r23-2', author: 'Priscila Gomes', date: '20/08/2026', rating: 5, comment: 'Arte pura! Cada quadradinho feito com tanto capricho. O vestido é único, vibrante e cheio de personalidade. Amei demais!' },
  ],
  p24: [
    { id: 'r24-1', author: 'Renata Campos', date: '19/08/2026', rating: 5, comment: 'Vestido lindo e sofisticado! As listras em tons terrosos são elegantes e a alça única é um detalhe moderno incrível. Artesanato de altíssima qualidade!' },
    { id: 'r24-2', author: 'Simone Barros', date: '20/08/2026', rating: 5, comment: 'Apaixonada! O vestido midi é perfeito — elegante, confortável e completamente único. Os tons terrosos combinam com tudo. Super recomendo!' },
  ],
  p25: [
    { id: 'r25-1', author: 'Tatiana Melo', date: '18/08/2026', rating: 5, comment: 'Bolsa deslumbrante! O branco com a corrente dourada e as pérolas é uma combinação de luxo. Artesanato impecável e muito sofisticado. Amei!' },
    { id: 'r25-2', author: 'Úrsula Nunes', date: '20/08/2026', rating: 5, comment: 'Peça de arte! A bolsa meia-lua é tendência e a Lilian fez com um acabamento incrível. As pérolas e a corrente dourada são detalhes que fazem toda a diferença!' },
  ],
  p26: [
    { id: 'r26-1', author: 'Vanessa Prado', date: '19/08/2026', rating: 5, comment: 'Bolsa tote mais linda que já vi! As flores de crochê rose são delicadas e bem aplicadas. Espaçosa, resistente e muito feminina. Perfeita para o dia a dia!' },
    { id: 'r26-2', author: 'Wanessa Ribeiro', date: '20/08/2026', rating: 5, comment: 'Simplesmente apaixonada! O rose/nude é delicado e as flores artesanais são um charme. Recebi elogios de todo mundo. Arte que se carrega com muito orgulho!' },
  ],
};