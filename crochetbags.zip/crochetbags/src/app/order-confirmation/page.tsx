'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { formatBRL } from '@/lib/store';

interface OrderItem {
  id: string;
  name: string;
  price: number;
  image: string;
  color: string;
  quantity: number;
}

interface OrderData {
  orderNumber: string;
  items: OrderItem[];
  shippingAddress: {
    cep: string;
    name: string;
  };
  subtotal: number;
  discount: number;
  shippingCost: number;
  total: number;
  shippingMethod: string;
  shippingDays: number;
  estimatedDelivery: string;
  placedAt: string;
}

export default function OrderConfirmationPage() {
  const [order, setOrder] = useState<OrderData | null>(null);

  useEffect(() => {
    try {
      const saved = localStorage.getItem('crochetbags_last_order');
      if (saved) {
        setOrder(JSON.parse(saved));
      }
    } catch {}
  }, []);

  if (!order) {
    return (
      <>
        <Header />
        <div className="max-w-2xl mx-auto px-4 text-center py-24 pt-36">
          <div className="mb-6">
            <Link href="/" className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              <Icon name="ArrowLeftIcon" size={16} />
              Voltar para o Início
            </Link>
          </div>
          <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center mx-auto mb-6">
            <Icon name="ShoppingBagIcon" size={36} className="text-muted-foreground" />
          </div>
          <h1 className="font-display text-2xl font-semibold text-foreground mb-3">
            Nenhum pedido encontrado
          </h1>
          <p className="text-muted-foreground mb-8">
            Explore nossa coleção e faça seu pedido pelo WhatsApp.
          </p>
          <Link href="/products" className="btn-primary">
            Ver Coleção
            <Icon name="ArrowRightIcon" size={18} />
          </Link>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Header />
      <div className="max-w-3xl mx-auto px-4 md:px-6 py-12 pt-28">

        {/* Back / Home button */}
        <div className="mb-6">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
          >
            <Icon name="ArrowLeftIcon" size={16} />
            Voltar para o Início
          </Link>
        </div>

        {/* Success Header */}
        <div className="text-center mb-10">
          <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-5">
            <Icon name="CheckCircleIcon" size={44} className="text-green-600" />
          </div>
          <h1 className="font-display text-3xl md:text-4xl font-semibold text-foreground mb-2">
            Pedido <span className="italic font-light text-accent">Confirmado!</span>
          </h1>
          <p className="text-muted-foreground text-base">
            Obrigada pela sua compra! Você receberá uma confirmação em breve.
          </p>
        </div>

        {/* Order Number + Date */}
        <div className="bg-accent/10 border border-accent/20 rounded-2xl p-5 mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold mb-1">Número do Pedido</p>
            <p className="font-display font-bold text-xl text-foreground tracking-wide">{order.orderNumber}</p>
          </div>
          <div className="sm:text-right">
            <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold mb-1">Data do Pedido</p>
            <p className="text-sm font-medium text-foreground">{order.placedAt}</p>
          </div>
        </div>

        {/* Estimated Delivery */}
        <div className="bg-card border border-border rounded-2xl p-5 mb-6 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center flex-shrink-0">
            <Icon name="TruckIcon" size={24} className="text-accent" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold mb-0.5">Previsão de Entrega</p>
            <p className="font-display font-semibold text-lg text-foreground">{order.estimatedDelivery}</p>
            <p className="text-xs text-muted-foreground mt-0.5">
              {order.shippingMethod} · até {order.shippingDays} dias úteis após postagem
            </p>
          </div>
        </div>

        {/* Items Ordered */}
        <div className="bg-card border border-border rounded-2xl p-5 mb-6">
          <h2 className="font-display font-semibold text-foreground text-lg mb-4 flex items-center gap-2">
            <Icon name="ShoppingBagIcon" size={18} className="text-accent" />
            Itens do Pedido
          </h2>
          <div className="space-y-4">
            {order.items.map((item) => (
              <div key={item.id} className="flex gap-4 items-center">
                <div className="relative w-16 h-16 rounded-xl overflow-hidden flex-shrink-0 bg-muted">
                  <AppImage
                    src={item.image}
                    alt={`${item.name} — item do pedido`}
                    fill
                    className="object-cover"
                    sizes="64px"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-display font-semibold text-foreground text-sm leading-tight">{item.name}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{item.color} · Qtd: {item.quantity}</p>
                </div>
                <span className="font-display font-bold text-foreground text-sm flex-shrink-0">
                  {formatBRL(item.price * item.quantity)}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Shipping Address + Cost Summary side by side on md+ */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-card border border-border rounded-2xl p-5">
            <h2 className="font-display font-semibold text-foreground text-base mb-3 flex items-center gap-2">
              <Icon name="MapPinIcon" size={16} className="text-accent" />
              Endereço de Entrega
            </h2>
            <p className="text-sm font-medium text-foreground">{order.shippingAddress.name}</p>
            <p className="text-sm text-muted-foreground mt-1">CEP: {order.shippingAddress.cep}</p>
          </div>

          <div className="bg-card border border-border rounded-2xl p-5">
            <h2 className="font-display font-semibold text-foreground text-base mb-3 flex items-center gap-2">
              <Icon name="ReceiptPercentIcon" size={16} className="text-accent" />
              Resumo de Valores
            </h2>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="text-foreground font-medium">{formatBRL(order.subtotal)}</span>
              </div>
              {order.discount > 0 && (
                <div className="flex justify-between">
                  <span className="text-green-600">Desconto</span>
                  <span className="text-green-600 font-medium">-{formatBRL(order.discount)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-muted-foreground">Frete ({order.shippingMethod})</span>
                {order.shippingCost === 0 ? (
                  <span className="text-green-600 font-medium">Grátis</span>
                ) : (
                  <span className="text-foreground font-medium">{formatBRL(order.shippingCost)}</span>
                )}
              </div>
              <div className="border-t border-border pt-2 flex justify-between">
                <span className="font-semibold text-foreground">Total</span>
                <span className="font-display font-bold text-lg text-foreground">{formatBRL(order.total)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link href="/products" className="btn-primary justify-center">
            Ver Catálogo
            <Icon name="ArrowRightIcon" size={18} />
          </Link>
          <Link
            href="/"
            className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-2xl border border-border text-foreground font-semibold text-sm hover:bg-muted transition-colors"
          >
            <Icon name="HomeIcon" size={16} />
            Ir para o Início
          </Link>
        </div>

        <p className="text-center text-xs text-muted-foreground mt-8 flex items-center justify-center gap-1.5">
          <Icon name="ShieldCheckIcon" size={13} className="text-accent" />
          Pedidos realizados via WhatsApp · Atendimento personalizado
        </p>
      </div>
      <Footer />
    </>
  );
}
