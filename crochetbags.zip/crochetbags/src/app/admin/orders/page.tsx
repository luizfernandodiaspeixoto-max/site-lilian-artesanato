'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import Icon from '@/components/ui/AppIcon';
import { formatBRL } from '@/lib/store';

type FulfillmentStatus = 'novo' | 'confirmado' | 'em_producao' | 'enviado' | 'entregue' | 'cancelado';

interface OrderItem {
  name: string;
  quantity: number;
  price: number;
}

interface AdminOrder {
  id: string;
  orderNumber: string;
  placedAt: string;
  status: FulfillmentStatus;
  trackingCode: string;
  customer: {
    name: string;
    phone: string;
    email: string;
    address: string;
    cep: string;
  };
  items: OrderItem[];
  total: number;
  paymentMethod: string;
  notes: string;
}

const STATUS_CONFIG: Record<FulfillmentStatus, { label: string; color: string; bg: string; icon: string }> = {
  novo:        { label: 'Novo',         color: 'text-blue-700',   bg: 'bg-blue-50 border-blue-200',   icon: 'InboxIcon' },
  confirmado:  { label: 'Confirmado',   color: 'text-amber-700',  bg: 'bg-amber-50 border-amber-200', icon: 'CheckIcon' },
  em_producao: { label: 'Em Produção',  color: 'text-purple-700', bg: 'bg-purple-50 border-purple-200', icon: 'WrenchScrewdriverIcon' },
  enviado:     { label: 'Enviado',      color: 'text-indigo-700', bg: 'bg-indigo-50 border-indigo-200', icon: 'TruckIcon' },
  entregue:    { label: 'Entregue',     color: 'text-green-700',  bg: 'bg-green-50 border-green-200', icon: 'CheckCircleIcon' },
  cancelado:   { label: 'Cancelado',    color: 'text-red-700',    bg: 'bg-red-50 border-red-200',     icon: 'XCircleIcon' },
};

const INITIAL_ORDERS: AdminOrder[] = [
  {
    id: '1',
    orderNumber: 'LIL-A3B7X2K9',
    placedAt: '2026-08-20T10:30:00',
    status: 'enviado',
    trackingCode: 'BR123456789BR',
    customer: {
      name: 'Maria Silva',
      phone: '(28) 99901-2345',
      email: 'maria.silva@email.com',
      address: 'Rua das Flores, 123 — Bairro Centro',
      cep: '29300-000',
    },
    items: [
      { name: 'Bolsa Azul Royal com Alça de Madeira', quantity: 1, price: 189 },
    ],
    total: 189,
    paymentMethod: 'PIX',
    notes: 'Cliente pediu embalagem para presente.',
  },
  {
    id: '2',
    orderNumber: 'LIL-C9D4Y1M3',
    placedAt: '2026-08-19T14:15:00',
    status: 'em_producao',
    trackingCode: '',
    customer: {
      name: 'Ana Beatriz Costa',
      phone: '(28) 99812-6789',
      email: 'anabeatriz@gmail.com',
      address: 'Av. Brasil, 456 — Bairro Jardim',
      cep: '29301-100',
    },
    items: [
      { name: 'Bolsa Hobo Vinho com Detalhes em Couro', quantity: 1, price: 239 },
      { name: 'Chinelo Customizado com Flores de Crochê', quantity: 1, price: 89 },
    ],
    total: 328,
    paymentMethod: 'Transferência Bancária',
    notes: '',
  },
  {
    id: '3',
    orderNumber: 'LIL-F2H8Z5P7',
    placedAt: '2026-08-18T09:00:00',
    status: 'novo',
    trackingCode: '',
    customer: {
      name: 'Juliana Ferreira',
      phone: '(28) 99723-4567',
      email: '',
      address: 'Rua Sete de Setembro, 789',
      cep: '29302-200',
    },
    items: [
      { name: 'Kit Cestinhas de Crochê Trio Candy', quantity: 1, price: 215 },
    ],
    total: 215,
    paymentMethod: 'PIX',
    notes: 'Aguardando confirmação de pagamento.',
  },
];

const STORAGE_KEY = 'lilian_admin_orders';

const AUTH_KEY = 'lilian_admin_auth';

function loadOrders(): AdminOrder[] {
  if (typeof window === 'undefined') return INITIAL_ORDERS;
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : INITIAL_ORDERS;
  } catch {
    return INITIAL_ORDERS;
  }
}

function saveOrders(orders: AdminOrder[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(orders));
  } catch {}
}

function formatDate(iso: string) {
  const d = new Date(iso);
  return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

export default function AdminOrdersPage() {
  const router = useRouter();
  const [orders, setOrders] = useState<AdminOrder[]>([]);
  const [filterStatus, setFilterStatus] = useState<FulfillmentStatus | 'todos'>('todos');
  const [search, setSearch] = useState('');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [editingOrder, setEditingOrder] = useState<AdminOrder | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [authed, setAuthed] = useState(false);

  useEffect(() => {
    if (localStorage.getItem(AUTH_KEY) !== 'true') {
      router.replace('/admin/login');
      return;
    }
    setAuthed(true);
    setOrders(loadOrders());
    setMounted(true);
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem(AUTH_KEY);
    router.replace('/admin/login');
  };

  const updateOrder = (updated: AdminOrder) => {
    const next = orders.map(o => o.id === updated.id ? updated : o);
    setOrders(next);
    saveOrders(next);
    setEditingOrder(null);
  };

  const addOrder = (newOrder: AdminOrder) => {
    const next = [newOrder, ...orders];
    setOrders(next);
    saveOrders(next);
    setShowAddModal(false);
  };

  const deleteOrder = (id: string) => {
    if (!confirm('Remover este pedido?')) return;
    const next = orders.filter(o => o.id !== id);
    setOrders(next);
    saveOrders(next);
    if (expandedId === id) setExpandedId(null);
  };

  const filtered = orders.filter(o => {
    const matchStatus = filterStatus === 'todos' || o.status === filterStatus;
    const q = search.toLowerCase();
    const matchSearch = !q || o.orderNumber.toLowerCase().includes(q) || o.customer.name.toLowerCase().includes(q) || o.customer.phone.includes(q);
    return matchStatus && matchSearch;
  });

  const counts = Object.keys(STATUS_CONFIG).reduce((acc, k) => {
    acc[k as FulfillmentStatus] = orders.filter(o => o.status === k).length;
    return acc;
  }, {} as Record<FulfillmentStatus, number>);

  if (!mounted || !authed) return null;

  return (
    <div className="min-h-screen bg-[#f8f5f2]">
      {/* Top Bar */}
      <div className="bg-white border-b border-stone-200 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Link href="/" className="flex items-center gap-1.5 text-sm text-stone-500 hover:text-stone-800 transition-colors">
              <Icon name="ArrowLeftIcon" size={15} />
              <span className="hidden sm:inline">Loja</span>
            </Link>
            <span className="text-stone-300">/</span>
            <h1 className="font-semibold text-stone-800 text-sm md:text-base flex items-center gap-2">
              <Icon name="ClipboardDocumentListIcon" size={18} className="text-rose-600" />
              Gestão de Pedidos
            </h1>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-1.5 bg-rose-600 hover:bg-rose-700 text-white text-sm font-semibold px-4 py-2 rounded-xl transition-colors"
            >
              <Icon name="PlusIcon" size={16} />
              <span className="hidden sm:inline">Novo Pedido</span>
            </button>
            <button
              onClick={handleLogout}
              title="Sair"
              className="flex items-center gap-1.5 text-sm text-stone-500 hover:text-red-600 border border-stone-200 hover:border-red-200 px-3 py-2 rounded-xl transition-colors"
            >
              <Icon name="ArrowRightOnRectangleIcon" size={16} />
              <span className="hidden sm:inline">Sair</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-6 py-6">
        {/* Status Summary Cards */}
        <div className="grid grid-cols-3 md:grid-cols-6 gap-2 mb-6">
          {(Object.keys(STATUS_CONFIG) as FulfillmentStatus[]).map(s => {
            const cfg = STATUS_CONFIG[s];
            return (
              <button
                key={s}
                onClick={() => setFilterStatus(filterStatus === s ? 'todos' : s)}
                className={`rounded-xl border p-3 text-left transition-all ${filterStatus === s ? cfg.bg + ' ' + cfg.color + ' border-current' : 'bg-white border-stone-200 text-stone-600 hover:border-stone-300'}`}
              >
                <p className="text-xl font-bold">{counts[s]}</p>
                <p className="text-xs font-medium mt-0.5 leading-tight">{cfg.label}</p>
              </button>
            );
          })}
        </div>

        {/* Search + Filter */}
        <div className="flex flex-col sm:flex-row gap-3 mb-5">
          <div className="relative flex-1">
            <Icon name="MagnifyingGlassIcon" size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              placeholder="Buscar por número do pedido ou cliente..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2.5 bg-white border border-stone-200 rounded-xl text-sm text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-rose-300"
            />
          </div>
          <select
            value={filterStatus}
            onChange={e => setFilterStatus(e.target.value as FulfillmentStatus | 'todos')}
            className="bg-white border border-stone-200 rounded-xl px-3 py-2.5 text-sm text-stone-700 focus:outline-none focus:ring-2 focus:ring-rose-300"
          >
            <option value="todos">Todos os status</option>
            {(Object.keys(STATUS_CONFIG) as FulfillmentStatus[]).map(s => (
              <option key={s} value={s}>{STATUS_CONFIG[s].label}</option>
            ))}
          </select>
        </div>

        {/* Orders List */}
        {filtered.length === 0 ? (
          <div className="bg-white rounded-2xl border border-stone-200 p-12 text-center">
            <Icon name="InboxIcon" size={40} className="text-stone-300 mx-auto mb-3" />
            <p className="text-stone-500 font-medium">Nenhum pedido encontrado</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map(order => {
              const cfg = STATUS_CONFIG[order.status];
              const isExpanded = expandedId === order.id;
              return (
                <div key={order.id} className="bg-white rounded-2xl border border-stone-200 overflow-hidden">
                  {/* Order Row */}
                  <div
                    className="flex items-center gap-3 px-4 py-4 cursor-pointer hover:bg-stone-50 transition-colors"
                    onClick={() => setExpandedId(isExpanded ? null : order.id)}
                  >
                    {/* Status Badge */}
                    <span className={`inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full border ${cfg.bg} ${cfg.color} flex-shrink-0`}>
                      <Icon name={cfg.icon} size={12} />
                      {cfg.label}
                    </span>

                    {/* Order Number */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono font-bold text-stone-800 text-sm">{order.orderNumber}</span>
                        <span className="text-stone-400 text-xs hidden sm:inline">·</span>
                        <span className="text-stone-600 text-sm font-medium hidden sm:inline">{order.customer.name}</span>
                      </div>
                      <div className="flex items-center gap-3 mt-0.5">
                        <span className="text-xs text-stone-400">{formatDate(order.placedAt)}</span>
                        {order.trackingCode && (
                          <span className="text-xs text-indigo-600 font-mono hidden md:inline">📦 {order.trackingCode}</span>
                        )}
                      </div>
                    </div>

                    {/* Total */}
                    <span className="font-bold text-stone-800 text-sm flex-shrink-0">{formatBRL(order.total)}</span>

                    {/* Expand Icon */}
                    <Icon
                      name={isExpanded ? 'ChevronUpIcon' : 'ChevronDownIcon'}
                      size={18}
                      className="text-stone-400 flex-shrink-0"
                    />
                  </div>

                  {/* Expanded Detail */}
                  {isExpanded && (
                    <div className="border-t border-stone-100 px-4 py-5 bg-stone-50/50">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">

                        {/* Customer Contact */}
                        <div className="bg-white rounded-xl border border-stone-200 p-4">
                          <h3 className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                            <Icon name="UserIcon" size={13} />
                            Dados do Cliente
                          </h3>
                          <p className="font-semibold text-stone-800 text-sm">{order.customer.name}</p>
                          {order.customer.phone && (
                            <a href={`https://wa.me/55${order.customer.phone.replace(/\D/g,'')}`} target="_blank" rel="noopener noreferrer"
                              className="flex items-center gap-1.5 text-green-600 hover:text-green-700 text-sm mt-1.5 transition-colors">
                              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-3.5 h-3.5">
                                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
                                <path d="M12 0C5.373 0 0 5.373 0 12c0 2.123.554 4.118 1.528 5.852L0 24l6.335-1.508A11.945 11.945 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.818 9.818 0 01-5.006-1.37l-.36-.213-3.76.895.952-3.653-.234-.374A9.818 9.818 0 1112 21.818z"/>
                              </svg>
                              {order.customer.phone}
                            </a>
                          )}
                          {order.customer.email && (
                            <a href={`mailto:${order.customer.email}`} className="flex items-center gap-1.5 text-stone-500 hover:text-stone-700 text-sm mt-1 transition-colors">
                              <Icon name="EnvelopeIcon" size={13} />
                              {order.customer.email}
                            </a>
                          )}
                          {order.customer.address && (
                            <p className="text-xs text-stone-500 mt-2 leading-relaxed">
                              <Icon name="MapPinIcon" size={12} className="inline mr-1" />
                              {order.customer.address}<br />CEP: {order.customer.cep}
                            </p>
                          )}
                        </div>

                        {/* Items + Payment */}
                        <div className="bg-white rounded-xl border border-stone-200 p-4">
                          <h3 className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                            <Icon name="ShoppingBagIcon" size={13} />
                            Itens do Pedido
                          </h3>
                          <div className="space-y-2">
                            {order.items.map((item, i) => (
                              <div key={i} className="flex justify-between gap-2 text-sm">
                                <span className="text-stone-700 leading-tight">{item.quantity}× {item.name}</span>
                                <span className="font-semibold text-stone-800 flex-shrink-0">{formatBRL(item.price * item.quantity)}</span>
                              </div>
                            ))}
                          </div>
                          <div className="border-t border-stone-100 mt-3 pt-3 flex justify-between">
                            <span className="text-sm font-semibold text-stone-700">Total</span>
                            <span className="font-bold text-stone-900">{formatBRL(order.total)}</span>
                          </div>
                          <div className="mt-2 flex items-center gap-1.5 text-xs text-stone-500">
                            <Icon name="CreditCardIcon" size={12} />
                            {order.paymentMethod}
                          </div>
                        </div>

                        {/* Fulfillment + Tracking */}
                        <div className="bg-white rounded-xl border border-stone-200 p-4">
                          <h3 className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                            <Icon name="TruckIcon" size={13} />
                            Fulfillment
                          </h3>

                          {/* Status Selector */}
                          <div className="mb-3">
                            <label className="text-xs text-stone-500 mb-1 block">Status</label>
                            <select
                              value={order.status}
                              onChange={e => updateOrder({ ...order, status: e.target.value as FulfillmentStatus })}
                              className="w-full bg-stone-50 border border-stone-200 rounded-lg px-3 py-2 text-sm text-stone-800 focus:outline-none focus:ring-2 focus:ring-rose-300"
                              onClick={e => e.stopPropagation()}
                            >
                              {(Object.keys(STATUS_CONFIG) as FulfillmentStatus[]).map(s => (
                                <option key={s} value={s}>{STATUS_CONFIG[s].label}</option>
                              ))}
                            </select>
                          </div>

                          {/* Tracking Code */}
                          <div className="mb-3">
                            <label className="text-xs text-stone-500 mb-1 block">Código de Rastreamento</label>
                            <div className="flex gap-2">
                              <input
                                type="text"
                                placeholder="AA123456789BR"
                                value={order.trackingCode}
                                onChange={e => updateOrder({ ...order, trackingCode: e.target.value.toUpperCase() })}
                                onClick={e => e.stopPropagation()}
                                className="flex-1 bg-stone-50 border border-stone-200 rounded-lg px-3 py-2 text-sm font-mono text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-rose-300"
                              />
                              {order.trackingCode && (
                                <a
                                  href={`https://rastreamento.correios.com.br/app/index.php?objetos=${order.trackingCode}`}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  onClick={e => e.stopPropagation()}
                                  className="flex items-center justify-center w-9 h-9 bg-indigo-50 hover:bg-indigo-100 text-indigo-600 rounded-lg transition-colors flex-shrink-0"
                                  title="Rastrear nos Correios"
                                >
                                  <Icon name="ArrowTopRightOnSquareIcon" size={15} />
                                </a>
                              )}
                            </div>
                          </div>

                          {/* Notes */}
                          <div>
                            <label className="text-xs text-stone-500 mb-1 block">Observações</label>
                            <textarea
                              rows={2}
                              placeholder="Anotações internas..."
                              value={order.notes}
                              onChange={e => updateOrder({ ...order, notes: e.target.value })}
                              onClick={e => e.stopPropagation()}
                              className="w-full bg-stone-50 border border-stone-200 rounded-lg px-3 py-2 text-sm text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-rose-300 resize-none"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex justify-end gap-2 mt-4">
                        <button
                          onClick={e => { e.stopPropagation(); setEditingOrder(order); }}
                          className="flex items-center gap-1.5 text-sm text-stone-600 hover:text-stone-800 bg-white border border-stone-200 hover:border-stone-300 px-3 py-2 rounded-xl transition-colors"
                        >
                          <Icon name="PencilIcon" size={14} />
                          Editar
                        </button>
                        <button
                          onClick={e => { e.stopPropagation(); deleteOrder(order.id); }}
                          className="flex items-center gap-1.5 text-sm text-red-600 hover:text-red-700 bg-red-50 hover:bg-red-100 border border-red-200 px-3 py-2 rounded-xl transition-colors"
                        >
                          <Icon name="TrashIcon" size={14} />
                          Remover
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        <p className="text-center text-xs text-stone-400 mt-8">
          {filtered.length} pedido{filtered.length !== 1 ? 's' : ''} exibido{filtered.length !== 1 ? 's' : ''} · Dados salvos localmente
        </p>
      </div>

      {/* Edit / Add Modal */}
      {(editingOrder || showAddModal) && (
        <OrderFormModal
          order={editingOrder}
          onSave={editingOrder ? updateOrder : addOrder}
          onClose={() => { setEditingOrder(null); setShowAddModal(false); }}
        />
      )}
    </div>
  );
}

/* ─── Order Form Modal ─── */
interface OrderFormModalProps {
  order: AdminOrder | null;
  onSave: (o: AdminOrder) => void;
  onClose: () => void;
}

function OrderFormModal({ order, onSave, onClose }: OrderFormModalProps) {
  const isNew = !order;
  const [form, setForm] = useState<AdminOrder>(order ?? {
    id: Date.now().toString(),
    orderNumber: `LIL-${Math.random().toString(36).substring(2, 10).toUpperCase()}`,
    placedAt: new Date().toISOString(),
    status: 'novo',
    trackingCode: '',
    customer: { name: '', phone: '', email: '', address: '', cep: '' },
    items: [{ name: '', quantity: 1, price: 0 }],
    total: 0,
    paymentMethod: 'PIX',
    notes: '',
  });

  const setCustomer = (field: keyof AdminOrder['customer'], value: string) =>
    setForm(f => ({ ...f, customer: { ...f.customer, [field]: value } }));

  const setItem = (i: number, field: keyof OrderItem, value: string | number) => {
    const items = form.items.map((it, idx) => idx === i ? { ...it, [field]: value } : it);
    const total = items.reduce((s, it) => s + (Number(it.price) * Number(it.quantity)), 0);
    setForm(f => ({ ...f, items, total }));
  };

  const addItem = () => setForm(f => ({ ...f, items: [...f.items, { name: '', quantity: 1, price: 0 }] }));
  const removeItem = (i: number) => {
    const items = form.items.filter((_, idx) => idx !== i);
    const total = items.reduce((s, it) => s + it.price * it.quantity, 0);
    setForm(f => ({ ...f, items, total }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(form);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200 sticky top-0 bg-white z-10">
          <h2 className="font-semibold text-stone-800 text-base">
            {isNew ? 'Novo Pedido' : `Editar ${form.orderNumber}`}
          </h2>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-stone-100 transition-colors">
            <Icon name="XMarkIcon" size={18} className="text-stone-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="px-6 py-5 space-y-5">
          {/* Order Info */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold text-stone-500 uppercase tracking-wider block mb-1.5">Nº do Pedido</label>
              <input value={form.orderNumber} onChange={e => setForm(f => ({ ...f, orderNumber: e.target.value }))}
                className="w-full border border-stone-200 rounded-xl px-3 py-2.5 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-rose-300" />
            </div>
            <div>
              <label className="text-xs font-semibold text-stone-500 uppercase tracking-wider block mb-1.5">Status</label>
              <select value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value as FulfillmentStatus }))}
                className="w-full border border-stone-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-rose-300">
                {(Object.keys(STATUS_CONFIG) as FulfillmentStatus[]).map(s => (
                  <option key={s} value={s}>{STATUS_CONFIG[s].label}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Customer */}
          <div>
            <h3 className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-3">Dados do Cliente</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {([['name','Nome completo'],['phone','Telefone / WhatsApp'],['email','E-mail'],['address','Endereço'],['cep','CEP']] as [keyof AdminOrder['customer'], string][]).map(([field, label]) => (
                <div key={field} className={field === 'address' ? 'sm:col-span-2' : ''}>
                  <label className="text-xs text-stone-500 block mb-1">{label}</label>
                  <input value={form.customer[field]} onChange={e => setCustomer(field, e.target.value)}
                    className="w-full border border-stone-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-rose-300" />
                </div>
              ))}
            </div>
          </div>

          {/* Items */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-semibold text-stone-500 uppercase tracking-wider">Itens</h3>
              <button type="button" onClick={addItem} className="text-xs text-rose-600 hover:text-rose-700 font-semibold flex items-center gap-1">
                <Icon name="PlusIcon" size={13} /> Adicionar item
              </button>
            </div>
            <div className="space-y-2">
              {form.items.map((item, i) => (
                <div key={i} className="flex gap-2 items-start">
                  <input placeholder="Nome do produto" value={item.name} onChange={e => setItem(i, 'name', e.target.value)}
                    className="flex-1 border border-stone-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-rose-300" />
                  <input type="number" min="1" placeholder="Qtd" value={item.quantity} onChange={e => setItem(i, 'quantity', parseInt(e.target.value) || 1)}
                    className="w-16 border border-stone-200 rounded-xl px-2 py-2 text-sm text-center focus:outline-none focus:ring-2 focus:ring-rose-300" />
                  <input type="number" min="0" placeholder="R$" value={item.price} onChange={e => setItem(i, 'price', parseFloat(e.target.value) || 0)}
                    className="w-24 border border-stone-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-rose-300" />
                  {form.items.length > 1 && (
                    <button type="button" onClick={() => removeItem(i)} className="w-9 h-9 flex items-center justify-center text-red-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-colors flex-shrink-0">
                      <Icon name="TrashIcon" size={15} />
                    </button>
                  )}
                </div>
              ))}
            </div>
            <div className="flex justify-end mt-2">
              <span className="text-sm font-bold text-stone-800">Total: {formatBRL(form.total)}</span>
            </div>
          </div>

          {/* Tracking + Payment */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold text-stone-500 uppercase tracking-wider block mb-1.5">Código de Rastreamento</label>
              <input placeholder="AA123456789BR" value={form.trackingCode} onChange={e => setForm(f => ({ ...f, trackingCode: e.target.value.toUpperCase() }))}
                className="w-full border border-stone-200 rounded-xl px-3 py-2.5 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-rose-300" />
            </div>
            <div>
              <label className="text-xs font-semibold text-stone-500 uppercase tracking-wider block mb-1.5">Forma de Pagamento</label>
              <select value={form.paymentMethod} onChange={e => setForm(f => ({ ...f, paymentMethod: e.target.value }))}
                className="w-full border border-stone-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-rose-300">
                <option>PIX</option>
                <option>Transferência Bancária</option>
                <option>Cartão de Crédito</option>
                <option>Cartão de Débito</option>
                <option>Dinheiro</option>
              </select>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="text-xs font-semibold text-stone-500 uppercase tracking-wider block mb-1.5">Observações</label>
            <textarea rows={3} placeholder="Anotações internas sobre o pedido..." value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
              className="w-full border border-stone-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-rose-300 resize-none" />
          </div>

          {/* Submit */}
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose}
              className="flex-1 border border-stone-200 text-stone-700 font-semibold py-3 rounded-xl hover:bg-stone-50 transition-colors text-sm">
              Cancelar
            </button>
            <button type="submit"
              className="flex-1 bg-rose-600 hover:bg-rose-700 text-white font-semibold py-3 rounded-xl transition-colors text-sm">
              {isNew ? 'Criar Pedido' : 'Salvar Alterações'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
