'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { formatBRL } from '@/lib/store';

interface OrderItem {
  id: string;
  name: string;
  price: number;
  image: string;
  color: string;
  quantity: number;
}

interface OrderData {
  orderNumber: string;
  items: OrderItem[];
  shippingAddress: {
    cep: string;
    name: string;
  };
  subtotal: number;
  discount: number;
  shippingCost: number;
  total: number;
  shippingMethod: string;
  shippingDays: number;
  estimatedDelivery: string;
  placedAt: string;
}

type ShippingStatus = 'confirmed' | 'preparing' | 'shipped' | 'out_for_delivery' | 'delivered';

function getShippingStatus(placedAt: string): ShippingStatus {
  const placed = new Date(placedAt.split('/').reverse().join('-'));
  const now = new Date();
  const diffDays = Math.floor((now.getTime() - placed.getTime()) / (1000 * 60 * 60 * 24));

  if (diffDays < 1) return 'confirmed';
  if (diffDays < 2) return 'preparing';
  if (diffDays < 5) return 'shipped';
  if (diffDays < 7) return 'out_for_delivery';
  return 'delivered';
}

const statusSteps: { key: ShippingStatus; label: string; icon: string; description: string }[] = [
  { key: 'confirmed', label: 'Pedido Confirmado', icon: 'CheckCircleIcon', description: 'Seu pedido foi recebido e confirmado' },
  { key: 'preparing', label: 'Em Preparação', icon: 'WrenchScrewdriverIcon', description: 'Sua peça está sendo produzida com carinho' },
  { key: 'shipped', label: 'Enviado', icon: 'TruckIcon', description: 'Pedido postado nos Correios' },
  { key: 'out_for_delivery', label: 'Saiu para Entrega', icon: 'MapPinIcon', description: 'Seu pedido está a caminho' },
  { key: 'delivered', label: 'Entregue', icon: 'HomeIcon', description: 'Pedido entregue com sucesso!' },
];

const statusOrder: ShippingStatus[] = ['confirmed', 'preparing', 'shipped', 'out_for_delivery', 'delivered'];

export default function OrderLookupPage() {
  const [orderNumber, setOrderNumber] = useState('');
  const [email, setEmail] = useState('');
  const [order, setOrder] = useState<OrderData | null>(null);
  const [error, setError] = useState('');
  const [searched, setSearched] = useState(false);

  function handleLookup(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setOrder(null);
    setSearched(false);

    if (!orderNumber.trim() || !email.trim()) {
      setError('Por favor, preencha o número do pedido e o e-mail.');
      return;
    }

    try {
      const saved = localStorage.getItem('crochetbags_last_order');
      if (saved) {
        const parsed: OrderData = JSON.parse(saved);
        const normalizedInput = orderNumber.trim().toUpperCase();
        const normalizedStored = parsed.orderNumber?.trim().toUpperCase();

        if (normalizedInput === normalizedStored) {
          setOrder(parsed);
          setSearched(true);
          return;
        }
      }
    } catch {}

    setSearched(true);
    setError('Pedido não encontrado. Verifique o número do pedido e tente novamente.');
  }

  const currentStatus: ShippingStatus = order ? getShippingStatus(order.placedAt) : 'confirmed';
  const currentStepIndex = statusOrder.indexOf(currentStatus);

  return (
    <>
      <Header />
      <div className="min-h-screen bg-background">
        <div className="max-w-3xl mx-auto px-4 md:px-6 py-12 pt-28">

          {/* Back / Home button */}
          <div className="mb-6">
            <Link
              href="/"
              className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              <Icon name="ArrowLeftIcon" size={16} />
              Voltar para o Início
            </Link>
          </div>

          {/* Page Header */}
          <div className="text-center mb-10">
            <div className="w-16 h-16 rounded-2xl bg-accent/10 flex items-center justify-center mx-auto mb-5">
              <Icon name="MagnifyingGlassIcon" size={32} className="text-accent" />
            </div>
            <h1 className="font-display text-3xl md:text-4xl font-semibold text-foreground mb-2">
              Consultar <span className="italic font-light text-accent">Pedido</span>
            </h1>
            <p className="text-muted-foreground text-base max-w-md mx-auto">
              Informe o número do pedido e seu e-mail para acompanhar o status e a previsão de entrega.
            </p>
          </div>

          {/* Lookup Form */}
          <div className="bg-card border border-border rounded-2xl p-6 md:p-8 mb-8 shadow-sm">
            <form onSubmit={handleLookup} className="space-y-5">
              <div>
                <label htmlFor="orderNumber" className="block text-sm font-semibold text-foreground mb-2">
                  Número do Pedido
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <Icon name="HashtagIcon" size={18} className="text-muted-foreground" />
                  </div>
                  <input
                    id="orderNumber"
                    type="text"
                    value={orderNumber}
                    onChange={(e) => setOrderNumber(e.target.value)}
                    placeholder="Ex: LIL-A1B2C3D4"
                    className="w-full pl-11 pr-4 py-3 rounded-xl border border-border bg-background text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:ring-2 focus:ring-accent/40 focus:border-accent transition-colors"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-semibold text-foreground mb-2">
                  E-mail do Pedido
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <Icon name="EnvelopeIcon" size={18} className="text-muted-foreground" />
                  </div>
                  <input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="seu@email.com"
                    className="w-full pl-11 pr-4 py-3 rounded-xl border border-border bg-background text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:ring-2 focus:ring-accent/40 focus:border-accent transition-colors"
                  />
                </div>
              </div>

              {error && (
                <div className="flex items-center gap-2.5 bg-red-50 border border-red-200 rounded-xl px-4 py-3">
                  <Icon name="ExclamationCircleIcon" size={18} className="text-red-500 flex-shrink-0" />
                  <p className="text-sm text-red-700">{error}</p>
                </div>
              )}

              <button
                type="submit"
                className="w-full btn-primary justify-center"
              >
                <Icon name="MagnifyingGlassIcon" size={18} />
                Consultar Pedido
              </button>
            </form>

            <p className="text-center text-xs text-muted-foreground mt-5 flex items-center justify-center gap-1.5">
              <Icon name="ShieldCheckIcon" size={13} className="text-accent" />
              Seus dados são protegidos e usados apenas para consulta
            </p>
          </div>

          {/* Order Results */}
          {order && (
            <div className="space-y-6 animate-fade-in">

              {/* Order Summary Banner */}
              <div className="bg-accent/10 border border-accent/20 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold mb-1">Número do Pedido</p>
                  <p className="font-display font-bold text-xl text-foreground tracking-wide">{order.orderNumber}</p>
                </div>
                <div className="sm:text-right">
                  <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold mb-1">Data do Pedido</p>
                  <p className="text-sm font-medium text-foreground">{order.placedAt}</p>
                </div>
              </div>

              {/* Shipping Progress */}
              <div className="bg-card border border-border rounded-2xl p-5 md:p-6">
                <h2 className="font-display font-semibold text-foreground text-lg mb-6 flex items-center gap-2">
                  <Icon name="TruckIcon" size={18} className="text-accent" />
                  Progresso do Envio
                </h2>

                <div className="space-y-0">
                  {statusSteps.map((step, index) => {
                    const isCompleted = index <= currentStepIndex;
                    const isCurrent = index === currentStepIndex;

                    return (
                      <div key={step.key} className="flex gap-4">
                        <div className="flex flex-col items-center">
                          <div
                            className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 transition-all ${
                              isCompleted
                                ? 'bg-accent text-primary shadow-sm'
                                : 'bg-muted text-muted-foreground'
                            } ${isCurrent ? 'ring-4 ring-accent/20' : ''}`}
                          >
                            <Icon name={step.icon as any} size={16} />
                          </div>
                          {index < statusSteps.length - 1 && (
                            <div
                              className={`w-0.5 flex-1 my-1 min-h-[24px] rounded-full transition-all ${
                                index < currentStepIndex ? 'bg-accent' : 'bg-border'
                              }`}
                            />
                          )}
                        </div>

                        <div className={`pb-6 ${index === statusSteps.length - 1 ? 'pb-0' : ''}`}>
                          <p
                            className={`text-sm font-semibold leading-tight ${
                              isCompleted ? 'text-foreground' : 'text-muted-foreground'
                            }`}
                          >
                            {step.label}
                            {isCurrent && (
                              <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-accent text-primary uppercase tracking-wide">
                                Atual
                              </span>
                            )}
                          </p>
                          <p className={`text-xs mt-0.5 ${isCompleted ? 'text-muted-foreground' : 'text-muted-foreground/50'}`}>
                            {step.description}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Estimated Delivery */}
              <div className="bg-card border border-border rounded-2xl p-5 flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center flex-shrink-0">
                  <Icon name="CalendarDaysIcon" size={24} className="text-accent" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold mb-0.5">Previsão de Entrega</p>
                  <p className="font-display font-semibold text-lg text-foreground">{order.estimatedDelivery}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {order.shippingMethod} · até {order.shippingDays} dias úteis após postagem
                  </p>
                </div>
              </div>

              {/* Items Ordered */}
              <div className="bg-card border border-border rounded-2xl p-5">
                <h2 className="font-display font-semibold text-foreground text-lg mb-4 flex items-center gap-2">
                  <Icon name="ShoppingBagIcon" size={18} className="text-accent" />
                  Itens do Pedido
                </h2>
                <div className="space-y-4">
                  {order.items.map((item) => (
                    <div key={item.id} className="flex gap-4 items-center">
                      <div className="relative w-16 h-16 rounded-xl overflow-hidden flex-shrink-0 bg-muted">
                        <AppImage
                          src={item.image}
                          alt={`${item.name} — item do pedido`}
                          fill
                          className="object-cover"
                          sizes="64px"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-display font-semibold text-foreground text-sm leading-tight">{item.name}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{item.color} · Qtd: {item.quantity}</p>
                      </div>
                      <span className="font-display font-bold text-foreground text-sm flex-shrink-0">
                        {formatBRL(item.price * item.quantity)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Cost Summary + Shipping Address */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="bg-card border border-border rounded-2xl p-5">
                  <h2 className="font-display font-semibold text-foreground text-base mb-3 flex items-center gap-2">
                    <Icon name="MapPinIcon" size={16} className="text-accent" />
                    Endereço de Entrega
                  </h2>
                  <p className="text-sm font-medium text-foreground">{order.shippingAddress.name}</p>
                  <p className="text-sm text-muted-foreground mt-1">CEP: {order.shippingAddress.cep}</p>
                </div>

                <div className="bg-card border border-border rounded-2xl p-5">
                  <h2 className="font-display font-semibold text-foreground text-base mb-3 flex items-center gap-2">
                    <Icon name="ReceiptPercentIcon" size={16} className="text-accent" />
                    Resumo de Valores
                  </h2>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Subtotal</span>
                      <span className="text-foreground font-medium">{formatBRL(order.subtotal)}</span>
                    </div>
                    {order.discount > 0 && (
                      <div className="flex justify-between">
                        <span className="text-green-600">Desconto</span>
                        <span className="text-green-600 font-medium">-{formatBRL(order.discount)}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Frete ({order.shippingMethod})</span>
                      {order.shippingCost === 0 ? (
                        <span className="text-green-600 font-medium">Grátis</span>
                      ) : (
                        <span className="text-foreground font-medium">{formatBRL(order.shippingCost)}</span>
                      )}
                    </div>
                    <div className="border-t border-border pt-2 flex justify-between">
                      <span className="font-semibold text-foreground">Total</span>
                      <span className="font-display font-bold text-lg text-foreground">{formatBRL(order.total)}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
                <Link href="/products" className="btn-primary justify-center">
                  Ver Catálogo
                  <Icon name="ArrowRightIcon" size={18} />
                </Link>
                <a
                  href="https://wa.me/5528999057982"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-2xl border border-border text-foreground font-semibold text-sm hover:bg-muted transition-colors"
                >
                  <Icon name="ChatBubbleLeftEllipsisIcon" size={16} className="text-green-600" />
                  Falar com a Lilian
                </a>
              </div>
            </div>
          )}

          {/* Not found state */}
          {searched && !order && !error && (
            <div className="text-center py-10">
              <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center mx-auto mb-4">
                <Icon name="InboxIcon" size={28} className="text-muted-foreground" />
              </div>
              <p className="font-display font-semibold text-foreground mb-1">Pedido não encontrado</p>
              <p className="text-sm text-muted-foreground">Verifique os dados e tente novamente.</p>
            </div>
          )}

          {/* Help note */}
          {!order && (
            <div className="mt-6 text-center">
              <p className="text-sm text-muted-foreground">
                Não encontrou seu pedido?{' '}
                <a
                  href="https://wa.me/5528999057982"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-green-600 font-semibold hover:underline"
                >
                  Fale com a Lilian pelo WhatsApp
                </a>
              </p>
            </div>
          )}
        </div>
      </div>
      <Footer />
    </>
  );
}
