import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import HeroSection from './components/HeroSection';
import CraftStory from './components/CraftStory';
import FeaturedProducts from './components/FeaturedProducts';
import TestimonialsSection from './components/TestimonialsSection';
import CTASection from './components/CTASection';
import RevealInit from './components/RevealInit';

export default function HomePage() {
  return (
    <>
      <Header />
      <main>
        <CraftStory />
        <HeroSection />
        <FeaturedProducts />
        <TestimonialsSection />
        <CTASection />
      </main>
      <Footer />
      <RevealInit />
    </>
  );
}