'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';
import { useCart } from '@/lib/cartContext';
import { formatBRL } from '@/lib/store';

const SHIPPING_THRESHOLD = 299;

interface ShippingOption {
  code: string;
  name: string;
  price: number;
  days: number;
}

interface ShippingResult {
  options: ShippingOption[];
  cep: string;
}

function calcShipping(cep: string, subtotal: number): ShippingOption[] {
  // Simulate Correios pricing based on CEP region
  const prefix = parseInt(cep.replace('-', '').substring(0, 2), 10);
  // ES region: 29xxx (prefix 29)
  const isLocal = prefix === 29;
  const isSouth = prefix >= 80 && prefix <= 99;
  const isNorth = prefix >= 60 && prefix <= 79;

  let pacBase = 18.9;
  let sedexBase = 32.5;

  if (isLocal) { pacBase = 14.5; sedexBase = 24.9; }
  else if (isSouth) { pacBase = 22.9; sedexBase = 38.9; }
  else if (isNorth) { pacBase = 25.9; sedexBase = 42.9; }

  // Weight simulation based on subtotal (more items = heavier)
  const weightFactor = subtotal > 200 ? 1.3 : 1;
  pacBase = Math.round(pacBase * weightFactor * 100) / 100;
  sedexBase = Math.round(sedexBase * weightFactor * 100) / 100;

  const pacDays = isLocal ? 3 : isSouth || isNorth ? 7 : 5;
  const sedexDays = isLocal ? 1 : isSouth || isNorth ? 3 : 2;

  return [
    { code: '04510', name: 'PAC', price: pacBase, days: pacDays },
    { code: '04014', name: 'SEDEX', price: sedexBase, days: sedexDays },
  ];
}

export default function CartClient() {
  const { items, removeItem, updateQty, subtotal, clearCart } = useCart();
  const router = useRouter();
  const [promoCode, setPromoCode] = useState('');
  const [promoApplied, setPromoApplied] = useState(false);
  const [promoError, setPromoError] = useState('');

  // Shipping calculator state
  const [cepInput, setCepInput] = useState('');
  const [shippingResult, setShippingResult] = useState<ShippingResult | null>(null);
  const [shippingLoading, setShippingLoading] = useState(false);
  const [shippingError, setShippingError] = useState('');
  const [selectedShipping, setSelectedShipping] = useState<ShippingOption | null>(null);

  const freeShipping = subtotal >= SHIPPING_THRESHOLD;
  const shippingCost = freeShipping || items?.length === 0 ? 0 : (selectedShipping ? selectedShipping.price : 0);
  const discount = promoApplied ? subtotal * 0.1 : 0;
  const total = subtotal - discount + shippingCost;

  const handlePromo = () => {
    if (promoCode?.toLowerCase() === 'crochet10') {
      setPromoApplied(true);
      setPromoError('');
    } else {
      setPromoError('Código inválido. Tente: CROCHET10');
    }
  };

  const formatCep = (value: string) => {
    const digits = value.replace(/\D/g, '').slice(0, 8);
    if (digits.length > 5) return `${digits.slice(0, 5)}-${digits.slice(5)}`;
    return digits;
  };

  const handleCepChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCepInput(formatCep(e.target.value));
    setShippingError('');
    if (shippingResult) { setShippingResult(null); setSelectedShipping(null); }
  };

  const handleCalcShipping = () => {
    const digits = cepInput.replace('-', '');
    if (digits.length !== 8) {
      setShippingError('Informe um CEP válido com 8 dígitos.');
      return;
    }
    setShippingLoading(true);
    setShippingError('');
    // Simulate async API call
    setTimeout(() => {
      const options = calcShipping(digits, subtotal);
      setShippingResult({ options, cep: cepInput });
      setShippingLoading(false);
    }, 900);
  };

  const handleCheckout = () => {
    // Generate order number
    const orderNumber = `LIL-${Date.now().toString().slice(-8).toUpperCase()}`;

    // Calculate estimated delivery
    const today = new Date();
    const shippingDays = freeShipping ? 5 : (selectedShipping?.days ?? 5);
    const deliveryDate = new Date(today);
    // Add business days (skip weekends)
    let daysAdded = 0;
    while (daysAdded < shippingDays + 2) {
      deliveryDate.setDate(deliveryDate.getDate() + 1);
      const day = deliveryDate.getDay();
      if (day !== 0 && day !== 6) daysAdded++;
    }
    const formattedDelivery = deliveryDate.toLocaleDateString('pt-BR', {
      weekday: 'long',
      day: '2-digit',
      month: 'long',
      year: 'numeric',
    });

    const orderData = {
      orderNumber,
      items: items.map((i) => ({
        id: i.id,
        name: i.name,
        price: i.price,
        image: i.image,
        color: i.color,
        quantity: i.quantity,
      })),
      shippingAddress: {
        cep: freeShipping ? '—' : (cepInput || '—'),
        name: 'Entrega via Correios',
      },
      subtotal,
      discount,
      shippingCost,
      total,
      shippingMethod: freeShipping ? 'Frete Grátis' : (selectedShipping?.name ?? 'PAC'),
      shippingDays: freeShipping ? 5 : (selectedShipping?.days ?? 5),
      estimatedDelivery: formattedDelivery,
      placedAt: today.toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: 'long',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
    };

    try {
      localStorage.setItem('crochetbags_last_order', JSON.stringify(orderData));
    } catch {}

    clearCart();
    router.push('/order-confirmation');
  };

  if (items?.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-4 text-center py-24">
        <div className="w-24 h-24 rounded-full bg-muted flex items-center justify-center mx-auto mb-6">
          <Icon name="ShoppingBagIcon" size={40} className="text-muted-foreground" />
        </div>
        <h1 className="font-display text-3xl font-semibold text-foreground mb-3">
          Seu carrinho está vazio
        </h1>
        <p className="text-muted-foreground mb-8">
          Explore nossa coleção e encontre a bolsa perfeita para você.
        </p>
        <Link href="/products" className="btn-primary">
          Ver Coleção
          <Icon name="ArrowRightIcon" size={18} />
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 md:px-6">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
        <Link href="/" className="hover:text-foreground transition-colors">Início</Link>
        <Icon name="ChevronRightIcon" size={14} />
        <Link href="/products" className="hover:text-foreground transition-colors">Catálogo</Link>
        <Icon name="ChevronRightIcon" size={14} />
        <span className="text-foreground font-medium">Carrinho</span>
      </nav>
      <h1 className="font-display text-hero-lg font-semibold text-foreground mb-8">
        Seu <span className="italic font-light text-accent">Carrinho</span>
      </h1>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-4">
          {/* Free shipping banner */}
          {!freeShipping && (
            <div className="p-4 rounded-2xl bg-accent/10 border border-accent/20 flex items-center gap-3">
              <Icon name="TruckIcon" size={20} className="text-accent flex-shrink-0" />
              <p className="text-sm text-foreground">
                Frete grátis em compras acima de{' '}
                <strong>{formatBRL(SHIPPING_THRESHOLD)}</strong>. Faltam{' '}
                <strong className="text-accent">{formatBRL(SHIPPING_THRESHOLD - subtotal)}</strong>.
              </p>
            </div>
          )}
          {freeShipping && (
            <div className="p-4 rounded-2xl bg-green-50 border border-green-200 flex items-center gap-3">
              <Icon name="TruckIcon" size={20} className="text-green-600 flex-shrink-0" />
              <p className="text-sm text-green-700 font-medium">🎉 Você ganhou frete grátis!</p>
            </div>
          )}

          {items?.map((item) => (
            <div
              key={item?.id}
              className="flex gap-4 p-4 rounded-2xl bg-card border border-border shadow-warm-sm"
            >
              {/* Image */}
              <div className="relative w-20 h-20 md:w-24 md:h-24 rounded-xl overflow-hidden flex-shrink-0 bg-muted">
                <AppImage
                  src={item?.image}
                  alt={`${item?.name} no carrinho`}
                  fill
                  className="object-cover"
                  sizes="96px"
                />
              </div>

              {/* Details */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="font-display font-semibold text-foreground text-base leading-tight">{item?.name}</h3>
                    <p className="text-xs text-muted-foreground mt-0.5">{item?.color}</p>
                  </div>
                  <button
                    onClick={() => removeItem(item?.id)}
                    className="flex-shrink-0 w-8 h-8 rounded-full hover:bg-red-50 flex items-center justify-center transition-colors"
                    aria-label={`Remover ${item?.name}`}
                  >
                    <Icon name="TrashIcon" size={15} className="text-muted-foreground hover:text-red-500" />
                  </button>
                </div>

                <div className="flex items-center justify-between mt-3">
                  {/* Qty stepper */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => updateQty(item?.id, item?.quantity - 1)}
                      className="qty-btn"
                      aria-label="Diminuir quantidade"
                    >
                      <Icon name="MinusIcon" size={14} />
                    </button>
                    <span className="font-semibold text-foreground w-6 text-center text-sm">{item?.quantity}</span>
                    <button
                      onClick={() => updateQty(item?.id, item?.quantity + 1)}
                      className="qty-btn"
                      aria-label="Aumentar quantidade"
                    >
                      <Icon name="PlusIcon" size={14} />
                    </button>
                  </div>

                  <span className="font-display font-bold text-foreground">
                    {formatBRL(item?.price * item?.quantity)}
                  </span>
                </div>
              </div>
            </div>
          ))}

          {/* Correios Shipping Calculator */}
          {!freeShipping && (
            <div className="p-5 rounded-2xl bg-card border border-border shadow-warm-sm">
              <div className="flex items-center gap-2 mb-4">
                <Icon name="TruckIcon" size={18} className="text-accent" />
                <h3 className="font-display font-semibold text-foreground text-base">Calcular Frete</h3>
                <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full ml-auto">Correios</span>
              </div>

              <div className="flex gap-2">
                <input
                  type="text"
                  value={cepInput}
                  onChange={handleCepChange}
                  placeholder="00000-000"
                  maxLength={9}
                  className="flex-1 px-3 py-2.5 text-sm border border-border rounded-xl bg-background focus:outline-none focus:border-accent"
                  onKeyDown={(e) => e.key === 'Enter' && handleCalcShipping()}
                />
                <button
                  onClick={handleCalcShipping}
                  disabled={shippingLoading || cepInput.replace('-', '').length < 8}
                  className="px-4 py-2.5 rounded-xl bg-accent text-primary text-sm font-semibold hover:bg-accent/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 min-w-[100px] justify-center"
                >
                  {shippingLoading ? (
                    <span className="inline-block w-4 h-4 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
                  ) : (
                    <>
                      <Icon name="MagnifyingGlassIcon" size={15} />
                      Calcular
                    </>
                  )}
                </button>
              </div>

              <a
                href="https://buscacepinter.correios.com.br/app/endereco/index.php"
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-accent hover:underline mt-1.5 inline-block"
              >
                Não sei meu CEP
              </a>

              {shippingError && (
                <p className="text-red-500 text-xs mt-2 flex items-center gap-1">
                  <Icon name="ExclamationCircleIcon" size={13} />
                  {shippingError}
                </p>
              )}

              {shippingResult && (
                <div className="mt-4 space-y-2">
                  <p className="text-xs text-muted-foreground mb-2">
                    Opções de entrega para o CEP <strong>{shippingResult.cep}</strong>:
                  </p>
                  {shippingResult.options.map((opt) => (
                    <label
                      key={opt.code}
                      className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-colors ${
                        selectedShipping?.code === opt.code
                          ? 'border-accent bg-accent/5' :'border-border hover:border-accent/50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <input
                          type="radio"
                          name="shipping"
                          value={opt.code}
                          checked={selectedShipping?.code === opt.code}
                          onChange={() => setSelectedShipping(opt)}
                          className="accent-[var(--color-accent)]"
                        />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-sm text-foreground">{opt.name}</span>
                            <span className="text-[10px] text-muted-foreground bg-muted px-1.5 py-0.5 rounded font-mono">
                              {opt.code}
                            </span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            Prazo estimado: até <strong>{opt.days} dias úteis</strong>
                          </p>
                        </div>
                      </div>
                      <span className="font-display font-bold text-foreground text-sm">
                        {formatBRL(opt.price)}
                      </span>
                    </label>
                  ))}
                  {!selectedShipping && (
                    <p className="text-xs text-muted-foreground mt-1">Selecione uma opção de frete para continuar.</p>
                  )}
                </div>
              )}
            </div>
          )}

          <div className="pt-2">
            <Link href="/products" className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              <Icon name="ArrowLeftIcon" size={16} />
              Continuar comprando
            </Link>
          </div>
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="bg-card border border-border rounded-3xl p-6 shadow-warm-md sticky top-28">
            <h2 className="font-display text-xl font-semibold text-foreground mb-6">Resumo do Pedido</h2>

            <div className="space-y-3 mb-6">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Subtotal ({items?.reduce((s, i) => s + i?.quantity, 0)} itens)</span>
                <span className="font-medium text-foreground">{formatBRL(subtotal)}</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-sm">
                  <span className="text-green-600">Desconto (10%)</span>
                  <span className="text-green-600 font-medium">-{formatBRL(discount)}</span>
                </div>
              )}
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Frete</span>
                {freeShipping ? (
                  <span className="font-medium text-green-600">Grátis</span>
                ) : selectedShipping ? (
                  <div className="text-right">
                    <span className="font-medium text-foreground">{formatBRL(selectedShipping.price)}</span>
                    <p className="text-[10px] text-muted-foreground">{selectedShipping.name} · {selectedShipping.days} dias úteis</p>
                  </div>
                ) : (
                  <span className="text-muted-foreground text-xs italic">Calcule o frete</span>
                )}
              </div>
              <div className="border-t border-border pt-3 flex justify-between">
                <span className="font-semibold text-foreground">Total</span>
                <span className="font-display font-bold text-xl text-foreground">{formatBRL(total)}</span>
              </div>
            </div>

            {/* Promo code */}
            <div className="mb-6">
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">
                Código Promocional
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={promoCode}
                  onChange={(e) => setPromoCode(e?.target?.value?.toUpperCase())}
                  placeholder="Ex: CROCHET10"
                  disabled={promoApplied}
                  className="flex-1 px-3 py-2 text-sm border border-border rounded-xl bg-background focus:outline-none focus:border-accent disabled:opacity-50 disabled:cursor-not-allowed"
                />
                <button
                  onClick={handlePromo}
                  disabled={promoApplied || !promoCode}
                  className="px-4 py-2 rounded-xl bg-muted text-foreground text-sm font-semibold hover:bg-accent hover:text-primary transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {promoApplied ? '✓' : 'Aplicar'}
                </button>
              </div>
              {promoError && <p className="text-red-500 text-xs mt-1">{promoError}</p>}
              {promoApplied && <p className="text-green-600 text-xs mt-1">✓ 10% de desconto aplicado!</p>}
            </div>

            {/* Checkout CTA */}
            <button
              onClick={handleCheckout}
              disabled={!freeShipping && !selectedShipping}
              className="w-full btn-primary justify-center !py-4 text-base group disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Finalizar Compra
              <Icon name="LockClosedIcon" size={16} className="opacity-70" />
            </button>

            {!freeShipping && !selectedShipping && (
              <p className="text-center text-xs text-amber-600 mt-2 flex items-center justify-center gap-1">
                <Icon name="InformationCircleIcon" size={13} />
                Calcule o frete para continuar
              </p>
            )}

            <p className="text-center text-xs text-muted-foreground mt-4 flex items-center justify-center gap-1.5">
              <Icon name="ShieldCheckIcon" size={13} className="text-accent" />
              Compra 100% segura · Pagamento protegido
            </p>

            {/* Payment icons */}
            <div className="flex items-center justify-center gap-3 mt-4 pt-4 border-t border-border">
              {['Pix', 'Cartão', 'Boleto']?.map((method) => (
                <span key={method} className="text-[10px] font-bold text-muted-foreground bg-muted px-2 py-1 rounded-md">
                  {method}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}