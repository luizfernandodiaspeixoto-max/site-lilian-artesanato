'use client';

import React from 'react';
import Icon from '@/components/ui/AppIcon';
import { Review } from '@/lib/store';

interface ProductReviewsModalProps {
  productName: string;
  rating: number;
  reviewCount: number;
  reviews: Review[];
  onClose: () => void;
}

function StarRating({ rating, size = 14 }: { rating: number; size?: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <Icon
          key={i}
          name="StarIcon"
          size={size}
          className={i < Math.floor(rating) ? 'text-accent' : i < rating ? 'text-accent/50' : 'text-border'}
          variant="solid"
        />
      ))}
    </div>
  );
}

export default function ProductReviewsModal({
  productName,
  rating,
  reviewCount,
  reviews,
  onClose,
}: ProductReviewsModalProps) {
  const ratingDistribution = [5, 4, 3, 2, 1].map((star) => ({
    star,
    count: reviews.filter((r) => r.rating === star).length,
    pct: Math.round((reviews.filter((r) => r.rating === star).length / reviews.length) * 100),
  }));

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
      onClick={onClose}
    >
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />

      {/* Modal */}
      <div
        className="relative w-full sm:max-w-lg bg-card border border-border rounded-t-3xl sm:rounded-2xl shadow-2xl max-h-[90vh] flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between p-5 border-b border-border shrink-0">
          <div>
            <h2 className="font-display font-semibold text-foreground text-base leading-tight line-clamp-2 pr-2">
              {productName}
            </h2>
            <p className="text-xs text-muted-foreground mt-0.5">Avaliações dos clientes</p>
          </div>
          <button
            onClick={onClose}
            className="shrink-0 w-8 h-8 flex items-center justify-center rounded-full bg-muted hover:bg-border transition-colors"
            aria-label="Fechar"
          >
            <Icon name="XMarkIcon" size={16} className="text-foreground" />
          </button>
        </div>

        {/* Rating Summary */}
        <div className="px-5 py-4 border-b border-border shrink-0 bg-muted/30">
          <div className="flex items-center gap-5">
            {/* Big score */}
            <div className="text-center">
              <p className="font-display text-4xl font-bold text-foreground leading-none">{rating.toFixed(1)}</p>
              <StarRating rating={rating} size={16} />
              <p className="text-xs text-muted-foreground mt-1">{reviewCount} avaliações</p>
            </div>

            {/* Distribution bars */}
            <div className="flex-1 space-y-1.5">
              {ratingDistribution.map(({ star, count, pct }) => (
                <div key={star} className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground w-3 text-right">{star}</span>
                  <Icon name="StarIcon" size={10} className="text-accent shrink-0" variant="solid" />
                  <div className="flex-1 h-1.5 bg-border rounded-full overflow-hidden">
                    <div
                      className="h-full bg-accent rounded-full transition-all duration-500"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <span className="text-xs text-muted-foreground w-4">{count}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Reviews list */}
        <div className="overflow-y-auto flex-1 divide-y divide-border">
          {reviews.map((review) => (
            <div key={review.id} className="px-5 py-4">
              <div className="flex items-start justify-between gap-3 mb-2">
                <div className="flex items-center gap-2.5">
                  {/* Avatar */}
                  <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center shrink-0">
                    <span className="text-xs font-bold text-accent">
                      {review.author.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground leading-tight">{review.author}</p>
                    <p className="text-xs text-muted-foreground">{review.date}</p>
                  </div>
                </div>
                <StarRating rating={review.rating} size={12} />
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed pl-10">{review.comment}</p>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-border shrink-0 bg-muted/20">
          <p className="text-xs text-center text-muted-foreground">
            ✦ Todas as avaliações são de clientes verificados
          </p>
        </div>
      </div>
    </div>
  );
}
