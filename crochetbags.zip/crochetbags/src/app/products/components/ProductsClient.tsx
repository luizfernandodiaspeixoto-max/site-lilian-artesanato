'use client';

import React, { useState, useEffect, useRef } from 'react';
import Link from 'next/link';

import Icon from '@/components/ui/AppIcon';
import { PRODUCTS, Product, PRODUCT_REVIEWS } from '@/lib/store';
import ProductReviewsModal from './ProductReviewsModal';

const CATEGORIES = ['Todos', 'Bolsa', 'Tote', 'Acessório', 'Hobo', 'Clutch', 'Roupa', 'Tiracolo', 'Baguete', 'Bucket', 'Kit'];
const COLORS = ['Todos', 'natural', 'colorido', 'neutro'];
const COLOR_LABELS: Record<string, string> = { natural: 'Natural', colorido: 'Colorido', neutro: 'Neutro' };
const SORT_OPTIONS = [
  { value: 'recent', label: 'Mais Recentes' },
  { value: 'popular', label: 'Mais Vendidos' },
];

function generateOrderCode(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code = 'LIL-';
  for (let i = 0; i < 8; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

interface OrderCodeModalProps {
  orderCode: string;
  productName: string;
  whatsappUrl: string;
  onClose: () => void;
}

function OrderCodeModal({ orderCode, productName, whatsappUrl, onClose }: OrderCodeModalProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(orderCode).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const handleWhatsApp = () => {
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-card border border-border rounded-2xl shadow-warm-lg w-full max-w-sm p-6 relative">
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-muted-foreground hover:text-foreground transition-colors"
          aria-label="Fechar"
        >
          <Icon name="XMarkIcon" size={20} />
        </button>

        {/* Header */}
        <div className="text-center mb-5">
          <div className="w-12 h-12 rounded-full bg-green-900/30 flex items-center justify-center mx-auto mb-3">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6 text-green-400">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
              <path d="M12 0C5.373 0 0 5.373 0 12c0 2.123.554 4.118 1.528 5.852L0 24l6.335-1.508A11.945 11.945 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.818 9.818 0 01-5.006-1.37l-.36-.213-3.76.895.952-3.653-.234-.374A9.818 9.818 0 1112 21.818z"/>
            </svg>
          </div>
          <h2 className="font-display text-lg font-semibold text-foreground">Seu Código de Pedido</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Guarde este código para acompanhar seu pedido no site
          </p>
        </div>

        {/* Order Code */}
        <div className="bg-accent/10 border border-accent/30 rounded-xl p-4 mb-4 text-center">
          <p className="text-xs text-muted-foreground mb-1 font-medium uppercase tracking-wider">Código do Pedido</p>
          <p className="font-mono text-2xl font-bold text-accent tracking-widest">{orderCode}</p>
          <p className="text-xs text-muted-foreground mt-1 truncate">{productName}</p>
        </div>

        {/* Copy button */}
        <button
          onClick={handleCopy}
          className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border border-border text-sm font-medium text-foreground hover:bg-muted/30 transition-colors mb-3"
        >
          <Icon name={copied ? 'CheckIcon' : 'ClipboardDocumentIcon'} size={16} className={copied ? 'text-green-400' : 'text-muted-foreground'} />
          {copied ? 'Código copiado!' : 'Copiar código'}
        </button>

        {/* Lookup link */}
        <p className="text-xs text-center text-muted-foreground mb-4">
          Consulte o status em{' '}
          <Link href="/order-lookup" className="text-accent hover:underline underline-offset-2" onClick={onClose}>
            Meu Pedido
          </Link>
        </p>

        {/* WhatsApp button */}
        <button
          onClick={handleWhatsApp}
          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-green-600 hover:bg-green-700 text-white text-sm font-semibold transition-colors"
        >
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
            <path d="M12 0C5.373 0 0 5.373 0 12c0 2.123.554 4.118 1.528 5.852L0 24l6.335-1.508A11.945 11.945 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.818 9.818 0 01-5.006-1.37l-.36-.213-3.76.895.952-3.653-.234-.374A9.818 9.818 0 1112 21.818z"/>
          </svg>
          Continuar para o WhatsApp
        </button>
      </div>
    </div>
  );
}

export default function ProductsClient() {
  const [activeCategory, setActiveCategory] = useState('Todos');
  const [activeColor, setActiveColor] = useState('Todos');
  const [sortBy, setSortBy] = useState('recent');
  const [reviewsProduct, setReviewsProduct] = useState<Product | null>(null);
  const [orderModal, setOrderModal] = useState<{ orderCode: string; productName: string; whatsappUrl: string } | null>(null);
  const sectionRef = useRef<HTMLDivElement>(null);

  const filtered = PRODUCTS.filter((p) => {
    const catMatch = activeCategory === 'Todos' || p.category === activeCategory;
    const colorMatch = activeColor === 'Todos' || p.color === activeColor;
    return catMatch && colorMatch;
  }).sort((a, b) => {
    if (sortBy === 'popular') return b.sold - a.sold;
    return 0;
  });

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add('active'); }),
      { threshold: 0.05 }
    );
    sectionRef.current?.querySelectorAll('.reveal').forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, [filtered]);

  const handleOrderClick = (product: Product) => {
    const orderCode = generateOrderCode();
    const message = `Olá! Tenho interesse na ${product.name}.\n\n📦 Código do Pedido: *${orderCode}*\n\nPor favor, me informe o preço e prazo de entrega.`;
    const whatsappUrl = `https://wa.me/5528999057982?text=${encodeURIComponent(message)}`;
    setOrderModal({ orderCode, productName: product.name, whatsappUrl });
  };

  return (
    <div className="max-w-6xl mx-auto px-4 md:px-6" ref={sectionRef}>
      {/* Page header */}
      <div className="mb-10 reveal">
        <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
          <Link href="/" className="hover:text-foreground transition-colors">Início</Link>
          <Icon name="ChevronRightIcon" size={14} />
          <span className="text-foreground font-medium">Catálogo</span>
        </nav>
        <h1 className="font-display text-hero-lg font-semibold text-foreground">
          Toda a <span className="italic font-light text-accent">Coleção</span>
        </h1>
        <p className="text-muted-foreground mt-2">{filtered.length} peças encontradas</p>
      </div>

      {/* Filters bar */}
      <div className="mb-8 space-y-4 reveal reveal-delay-1">
        <div className="flex flex-wrap gap-2">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`filter-chip ${activeCategory === cat ? 'active' : ''}`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap gap-2">
            {COLORS.map((c) => (
              <button
                key={c}
                onClick={() => setActiveColor(c)}
                className={`filter-chip ${activeColor === c ? 'active' : ''}`}
              >
                {c === 'Todos' ? 'Todas as cores' : COLOR_LABELS[c]}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <Icon name="AdjustmentsHorizontalIcon" size={16} className="text-muted-foreground" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="text-sm font-medium text-foreground bg-card border border-border rounded-xl px-3 py-2 outline-none focus:border-accent cursor-pointer"
            >
              {SORT_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Product Grid */}
      {filtered.length === 0 ? (
        <div className="text-center py-24">
          <Icon name="ShoppingBagIcon" size={48} className="text-muted-foreground mx-auto mb-4" />
          <p className="font-display text-xl text-foreground mb-2">Nenhuma peça encontrada</p>
          <p className="text-muted-foreground text-sm">Tente outros filtros</p>
          <button onClick={() => { setActiveCategory('Todos'); setActiveColor('Todos'); }} className="btn-primary mt-6">
            Limpar filtros
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {filtered.map((product, i) => (
            <div
              key={product.id}
              className="product-card group rounded-2xl overflow-hidden bg-card border border-border shadow-warm-sm hover:shadow-warm-md transition-all duration-300"
              style={{ transitionDelay: `${(i % 4) * 60}ms` }}
            >
              {/* Image */}
              <div className="relative w-full bg-[#F5F0EA]" style={{ aspectRatio: '1 / 1' }}>
                <img
                  src={product.image}
                  alt={`${product.name} — ${product.description}`}
                  className="absolute inset-0 w-full h-full object-contain p-2"
                />
                {product.badge && (
                  <div className="absolute top-3 left-3 badge-handmade z-10">{product.badge}</div>
                )}
              </div>

              {/* Info */}
              <div className="p-4">
                <p className="text-xs text-muted-foreground mb-1 font-medium">{product.category} · {product.colorLabel}</p>
                <h3 className="font-display font-semibold text-foreground text-base mb-2 leading-tight">{product.name}</h3>
                <p className="text-xs text-muted-foreground leading-relaxed mb-3 line-clamp-2">{product.description}</p>

                {/* Rating */}
                <div className="flex items-center gap-1.5 mb-3">
                  <div className="flex gap-0.5">
                    {Array.from({ length: 5 }).map((_, j) => (
                      <Icon
                        key={j}
                        name="StarIcon"
                        size={12}
                        className={j < Math.floor(product.rating) ? 'text-accent' : 'text-border'}
                        variant="solid"
                      />
                    ))}
                  </div>
                  <button
                    onClick={() => setReviewsProduct(product)}
                    className="text-xs text-accent hover:underline underline-offset-2 transition-colors cursor-pointer"
                  >
                    ({product.reviews} avaliações)
                  </button>
                </div>

                {/* Price sob encomenda */}
                <div className="mb-3">
                  <span className="inline-flex items-center gap-1.5 text-sm font-semibold text-accent bg-accent/10 px-3 py-1 rounded-full">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-3.5 h-3.5">
                      <path d="M20 7H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"/>
                      <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>
                    </svg>
                    Preço sob encomenda
                  </span>
                </div>

                {/* WhatsApp */}
                <div className="pt-3 border-t border-border">
                  <button
                    onClick={() => handleOrderClick(product)}
                    className="flex items-center justify-center gap-1.5 w-full py-2 rounded-xl bg-green-900/30 hover:bg-green-800/40 text-green-400 text-xs font-semibold transition-colors cursor-pointer"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-3.5 h-3.5">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
                      <path d="M12 0C5.373 0 0 5.373 0 12c0 2.123.554 4.118 1.528 5.852L0 24l6.335-1.508A11.945 11.945 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.818 9.818 0 01-5.006-1.37l-.36-.213-3.76.895.952-3.653-.234-.374A9.818 9.818 0 1112 21.818z"/>
                    </svg>
                    Pedir via WhatsApp
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Reviews Modal */}
      {reviewsProduct && (
        <ProductReviewsModal
          productName={reviewsProduct.name}
          rating={reviewsProduct.rating}
          reviewCount={reviewsProduct.reviews}
          reviews={PRODUCT_REVIEWS[reviewsProduct.id] ?? []}
          onClose={() => setReviewsProduct(null)}
        />
      )}

      {/* Order Code Modal */}
      {orderModal && (
        <OrderCodeModal
          orderCode={orderModal.orderCode}
          productName={orderModal.productName}
          whatsappUrl={orderModal.whatsappUrl}
          onClose={() => setOrderModal(null)}
        />
      )}
    </div>
  );
}