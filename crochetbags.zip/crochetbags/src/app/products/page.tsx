import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ProductsClient from './components/ProductsClient';

export const metadata = {
  title: 'Catálogo — CrochetBags',
  description: 'Explore toda a coleção de bolsas de crochê artesanais. Filtre por tipo, cor e preço.',
};

export default function ProductsPage() {
  return (
    <>
      <Header />
      <main className="pt-28 pb-20">
        <ProductsClient />
      </main>
      <Footer />
    </>
  );
}