'use client';

import React, { useEffect, useRef } from 'react';
import Link from 'next/link';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';
import { PRODUCTS } from '@/lib/store';

const featured = PRODUCTS?.slice(0, 6);

export default function FeaturedProducts() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('active');
          }
        });
      },
      { threshold: 0.08, rootMargin: '0px 0px -40px 0px' }
    );
    const els = sectionRef?.current?.querySelectorAll('.reveal');
    els?.forEach((el) => observer?.observe(el));
    return () => observer?.disconnect();
  }, []);

  // Bento audit: 6 cards
  // Row 1: [col-1: p1 cs-1 rs-2] [col-2: p2 cs-1] [col-3: p3 cs-1]
  // Row 2: [col-1: FILLED p1]    [col-2: p4 cs-2]
  // Row 3: [col-1: p5 cs-2]      [col-3: p6 cs-1]
  // 6/6 placed ✓

  return (
    <section id="featured" className="py-16 md:py-24 px-4 md:px-6" ref={sectionRef}>
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="reveal">
            <span className="text-[11px] uppercase tracking-[0.3em] text-muted-foreground font-semibold mb-3 block">
              Coleção em Destaque
            </span>
            <h2 className="font-display text-section-title font-semibold text-foreground">
              Peças que as mulheres<br />
              <span className="italic font-light text-accent">mais amam.</span>
            </h2>
          </div>
          <div className="reveal reveal-delay-2">
            <Link href="/products" className="btn-outline flex-shrink-0">
              Ver Todas
              <Icon name="ArrowRightIcon" size={16} />
            </Link>
          </div>
        </div>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 auto-rows-[280px]">
          {/* Card p1 — col-span-1 row-span-2 */}
          <div className="reveal product-card md:row-span-2 rounded-3xl overflow-hidden relative group cursor-pointer bg-muted">
            <div className="absolute inset-0 overflow-hidden">
              <AppImage
                src={featured?.[0]?.image}
                alt={featured?.[0]?.name ?? 'Produto artesanal Lilian Artesanato'}
                fill
                className="object-cover product-card-img"
                sizes="(max-width: 768px) 100vw, 33vw"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-primary/75 via-primary/10 to-transparent" />
            {featured?.[0]?.badge && (
              <div className="absolute top-4 left-4 badge-handmade z-10">{featured?.[0]?.badge}</div>
            )}
            <div className="absolute bottom-0 left-0 right-0 p-5 z-10">
              <p className="text-white/70 text-xs mb-1">{featured?.[0]?.category}</p>
              <h3 className="font-display text-xl font-semibold text-white mb-2">{featured?.[0]?.name}</h3>
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-accent/90 bg-white/10 backdrop-blur-sm px-2.5 py-1 rounded-full">Sob encomenda</span>
              </div>
            </div>
          </div>

          {/* Card p2 — col-span-1 row-span-1 */}
          <div className="reveal reveal-delay-1 product-card rounded-3xl overflow-hidden relative group cursor-pointer bg-muted">
            <div className="absolute inset-0 overflow-hidden">
              <AppImage
                src={featured?.[1]?.image}
                alt={featured?.[1]?.name ?? 'Produto artesanal Lilian Artesanato'}
                fill
                className="object-cover product-card-img"
                sizes="(max-width: 768px) 100vw, 33vw"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-primary/70 via-transparent to-transparent" />
            {featured?.[1]?.badge && (
              <div className="absolute top-4 left-4 badge-handmade z-10">{featured?.[1]?.badge}</div>
            )}
            <div className="absolute bottom-0 left-0 right-0 p-4 z-10">
              <h3 className="font-display text-base font-semibold text-white">{featured?.[1]?.name}</h3>
              <div className="flex items-center justify-between mt-1">
                <span className="text-xs font-semibold text-accent/90 bg-white/10 backdrop-blur-sm px-2.5 py-1 rounded-full">Sob encomenda</span>
              </div>
            </div>
          </div>

          {/* Card p3 — col-span-1 row-span-1 */}
          <div className="reveal reveal-delay-2 product-card rounded-3xl overflow-hidden relative group cursor-pointer bg-muted">
            <div className="absolute inset-0 overflow-hidden">
              <AppImage
                src={featured?.[2]?.image}
                alt={featured?.[2]?.name ?? 'Produto artesanal Lilian Artesanato'}
                fill
                className="object-cover product-card-img"
                sizes="(max-width: 768px) 100vw, 33vw"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-primary/70 via-transparent to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-4 z-10">
              <h3 className="font-display text-base font-semibold text-white">{featured?.[2]?.name}</h3>
              <div className="flex items-center justify-between mt-1">
                <span className="text-xs font-semibold text-accent/90 bg-white/10 backdrop-blur-sm px-2.5 py-1 rounded-full">Sob encomenda</span>
              </div>
            </div>
          </div>

          {/* Card p4 — col-span-2 row-span-1 */}
          <div className="reveal reveal-delay-1 product-card md:col-span-2 rounded-3xl overflow-hidden relative group cursor-pointer bg-muted">
            <div className="absolute inset-0 overflow-hidden">
              <AppImage
                src={featured?.[3]?.image}
                alt={featured?.[3]?.name ?? 'Produto artesanal Lilian Artesanato'}
                fill
                className="object-cover product-card-img object-center"
                sizes="(max-width: 768px) 100vw, 66vw"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-r from-primary/70 via-primary/20 to-transparent" />
            <div className="absolute bottom-0 left-0 p-6 z-10">
              <p className="text-white/70 text-xs mb-1">{featured?.[3]?.category}</p>
              <h3 className="font-display text-2xl font-semibold text-white mb-2">{featured?.[3]?.name}</h3>
              <div className="flex items-center gap-4">
                <span className="text-xs font-semibold text-accent/90 bg-white/10 backdrop-blur-sm px-2.5 py-1 rounded-full">Sob encomenda</span>
              </div>
            </div>
          </div>

          {/* Card p5 — col-span-2 row-span-1 */}
          <div className="reveal reveal-delay-2 product-card md:col-span-2 rounded-3xl overflow-hidden relative group cursor-pointer bg-muted">
            <div className="absolute inset-0 overflow-hidden">
              <AppImage
                src={featured?.[4]?.image}
                alt={featured?.[4]?.name ?? 'Produto artesanal Lilian Artesanato'}
                fill
                className="object-cover product-card-img object-center"
                sizes="(max-width: 768px) 100vw, 66vw"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-r from-primary/70 via-primary/20 to-transparent" />
            {featured?.[4]?.badge && (
              <div className="absolute top-4 left-4 badge-handmade z-10">{featured?.[4]?.badge}</div>
            )}
            <div className="absolute bottom-0 left-0 p-6 z-10">
              <p className="text-white/70 text-xs mb-1">{featured?.[4]?.category}</p>
              <h3 className="font-display text-2xl font-semibold text-white mb-2">{featured?.[4]?.name}</h3>
              <div className="flex items-center gap-4">
                <span className="text-xs font-semibold text-accent/90 bg-white/10 backdrop-blur-sm px-2.5 py-1 rounded-full">Sob encomenda</span>
              </div>
            </div>
          </div>

          {/* Card p6 — col-span-1 row-span-1 */}
          <div className="reveal reveal-delay-3 product-card rounded-3xl overflow-hidden relative group cursor-pointer bg-muted">
            <div className="absolute inset-0 overflow-hidden">
              <AppImage
                src={featured?.[5]?.image}
                alt={featured?.[5]?.name ?? 'Produto artesanal Lilian Artesanato'}
                fill
                className="object-cover product-card-img"
                sizes="(max-width: 768px) 100vw, 33vw"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-primary/70 via-transparent to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-4 z-10">
              <h3 className="font-display text-base font-semibold text-white">{featured?.[5]?.name}</h3>
              <div className="flex items-center justify-between mt-1">
                <span className="text-xs font-semibold text-accent/90 bg-white/10 backdrop-blur-sm px-2.5 py-1 rounded-full">Sob encomenda</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}