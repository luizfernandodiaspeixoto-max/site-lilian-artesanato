'use client';

import React, { useEffect, useRef } from 'react';
import Link from 'next/link';
import Icon from '@/components/ui/AppIcon';

export default function CTASection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) entry.target.classList.add('active');
        });
      },
      { threshold: 0.1 }
    );
    sectionRef?.current?.querySelectorAll('.reveal')?.forEach((el) => observer?.observe(el));
    return () => observer?.disconnect();
  }, []);

  return (
    <section className="py-12 pb-20 px-4 md:px-6" ref={sectionRef}>
      <div className="max-w-6xl mx-auto">
        <div className="relative overflow-hidden rounded-[2.5rem] bg-gradient-to-br from-rose-700 via-pink-700 to-rose-900 px-8 py-16 md:py-20 text-center shadow-warm-xl border border-white/5">
          {/* Atmospheric glow */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] pointer-events-none" aria-hidden>
            <div className="absolute inset-0 bg-radial-gradient" style={{ background: 'radial-gradient(circle at center, rgba(196,149,106,0.18) 0%, transparent 70%)' }} />
          </div>

          {/* Floating decorative icons */}
          <div className="absolute top-8 left-12 opacity-15 animate-float hidden lg:block" aria-hidden>
            <Icon name="SparklesIcon" size={40} className="text-accent" />
          </div>
          <div className="absolute bottom-8 right-12 opacity-15 animation-delay-2000 animate-float-slow hidden lg:block" aria-hidden>
            <Icon name="HeartIcon" size={48} className="text-accent" variant="solid" />
          </div>
          <div className="absolute top-16 right-24 opacity-10 animate-float hidden lg:block" aria-hidden>
            <Icon name="StarIcon" size={32} className="text-secondary" variant="solid" />
          </div>

          <div className="relative z-10 max-w-2xl mx-auto">
            <div className="reveal inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-white/10 bg-white/5 mb-6">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping-slow absolute inline-flex h-full w-full rounded-full bg-accent opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-accent" />
              </span>
              <span className="text-[10px] uppercase tracking-[0.2em] font-bold text-white/60">
                Nova coleção disponível
              </span>
            </div>

            <h2 className="reveal reveal-delay-1 font-display text-hero-lg font-semibold text-primary-foreground mb-4">
              Encontre sua bolsa<br />
              <span className="italic font-light text-accent">perfeita.</span>
            </h2>

            <p className="reveal reveal-delay-2 text-lg text-white/60 mb-10 leading-relaxed">
              Mais de 30 modelos artesanais esperando por você. Cada peça única, cada detalhe pensado com carinho.
            </p>

            <div className="reveal reveal-delay-3 flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/products" className="btn-primary !bg-accent !text-primary group">
                Explorar Catálogo
                <Icon name="ArrowRightIcon" size={18} className="group-hover:translate-x-1 transition-transform" />
              </Link>
              <a
                href="https://wa.me/5528999057982"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white font-semibold px-6 py-3 rounded-full transition-colors"
              >
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
                  <path d="M12 0C5.373 0 0 5.373 0 12c0 2.123.554 4.118 1.528 5.852L0 24l6.335-1.508A11.945 11.945 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.818 9.818 0 01-5.006-1.37l-.36-.213-3.76.895.952-3.653-.234-.374A9.818 9.818 0 1112 21.818z"/>
                </svg>
                Falar no WhatsApp
              </a>
            </div>

            {/* Made-to-order notice */}
            <div className="reveal reveal-delay-4 mt-8 inline-flex items-center gap-2 px-5 py-3 rounded-2xl border border-accent/20 bg-white/5">
              <span className="text-lg">🧶</span>
              <p className="text-sm text-white/70">
                <strong className="text-white">Feito por Encomenda</strong> · 50% de depósito para confirmar o pedido
              </p>
            </div>

            {/* Stats row */}
            <div className="reveal reveal-delay-4 mt-12 pt-8 border-t border-white/10 flex items-center justify-center gap-8 flex-wrap">
              {[
                { v: '500+', l: 'Clientes' },
                { v: 'R$139', l: 'A partir de' },
                { v: '24h', l: 'Envio' },
              ]?.map((s, i) => (
                <React.Fragment key={s?.l}>
                  {i > 0 && <div className="h-8 w-px bg-white/10 hidden sm:block" />}
                  <div className="text-center">
                    <p className="font-display text-2xl font-bold text-primary-foreground">{s?.v}</p>
                    <p className="text-[10px] uppercase tracking-widest text-white/40 mt-0.5">{s?.l}</p>
                  </div>
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}