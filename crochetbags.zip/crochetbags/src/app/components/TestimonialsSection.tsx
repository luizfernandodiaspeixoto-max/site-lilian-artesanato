'use client';

import React, { useEffect, useRef } from 'react';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';

const testimonials = [
{
  name: 'Mariana Oliveira',
  city: 'São Paulo, SP',
  avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1b0e993b5-1768445246624.png",
  rating: 5,
  text: 'Comprei a bolsa praia e recebi em perfeito estado. A qualidade do crochê é impecável — todo mundo pergunta onde comprei. Já pedi a segunda!',
  product: 'Bolsa Praia Boho'
},
{
  name: 'Camila Ferreira',
  city: 'Rio de Janeiro, RJ',
  avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_147fe6c87-1767031135270.png",
  rating: 5,
  text: 'A mini bag caramelo é perfeita. Pequena, charmosa e muito bem feita. Uso no dia a dia e recebo elogios sempre. Vale cada centavo!',
  product: 'Mini Bag Caramelo'
},
{
  name: 'Fernanda Santos',
  city: 'Belo Horizonte, MG',
  avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_168835c51-1784426330070.png",
  rating: 5,
  text: 'Presente para minha mãe e ela amou. O acabamento é incrível, parece que cada ponto foi feito com muito cuidado. Entrega rápida também.',
  product: 'Evening Bag Prata'
},
{
  name: 'Juliana Costa',
  city: 'Vitória, ES',
  avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1bf517805-1773990512446.png",
  rating: 5,
  text: 'A Lilian é super atenciosa! Fiz uma encomenda personalizada e ela me atualizou em cada etapa. A bolsa ficou exatamente como eu queria. Recomendo demais!',
  product: 'Encomenda Personalizada'
},
{
  name: 'Patrícia Almeida',
  city: 'Curitiba, PR',
  avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_15c43327a-1772856393660.png",
  rating: 5,
  text: 'Comprei como presente de aniversário e a aniversariante ficou encantada. A bolsa é linda, resistente e com um acabamento que você não encontra em loja nenhuma.',
  product: 'Bolsa Festa Nude'
},
{
  name: 'Renata Moura',
  city: 'Salvador, BA',
  avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_181dfbcd4-1767883807129.png",
  rating: 5,
  text: 'Já é minha terceira compra com a Lilian! Cada peça é única e especial. O atendimento pelo WhatsApp é rápido e ela tira todas as dúvidas com muita simpatia.',
  product: 'Coleção Verão'
}];


export default function TestimonialsSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) entry.target.classList.add('active');
        });
      },
      { threshold: 0.08 }
    );
    sectionRef?.current?.querySelectorAll('.reveal')?.forEach((el) => observer?.observe(el));
    return () => observer?.disconnect();
  }, []);

  return (
    <section className="py-16 md:py-24 px-4 md:px-6 bg-muted" ref={sectionRef}>
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12 reveal">
          <span className="text-[11px] uppercase tracking-[0.3em] text-muted-foreground font-semibold mb-3 block">
            O que dizem nossas clientes
          </span>
          <h2 className="font-display text-section-title font-semibold text-foreground">
            Amor real,<br />
            <span className="italic font-light text-accent">palavras verdadeiras.</span>
          </h2>
        </div>

        {/* Featured large testimonial */}
        <div className="reveal mb-8">
          <div className="glass-card rounded-3xl p-8 md:p-10 shadow-warm-lg relative overflow-hidden">
            <div className="absolute top-6 right-8 opacity-10">
              <Icon name="ChatBubbleLeftRightIcon" size={80} className="text-accent" variant="solid" />
            </div>
            <div className="flex gap-1 mb-4">
              {Array.from({ length: 5 })?.map((_, j) =>
              <Icon key={j} name="StarIcon" size={20} className="text-accent" variant="solid" />
              )}
            </div>
            <p className="text-foreground text-lg md:text-xl leading-relaxed mb-6 font-display italic font-light max-w-3xl">
              &ldquo;Já é minha terceira compra com a Lilian! Cada peça é única e especial. O atendimento pelo WhatsApp é rápido e ela tira todas as dúvidas com muita simpatia. As bolsas são resistentes, lindas e recebo elogios toda vez que uso. Não troco por nada!&rdquo;
            </p>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full overflow-hidden flex-shrink-0 border-2 border-accent/30">
                <AppImage
                  src="https://img.rocket.new/generatedImages/rocket_gen_img_131b3bb16-1784880253265.png"
                  alt="Foto de Ana Paula, cliente fiel do Lilian Artesanato"
                  width={48}
                  height={48}
                  className="object-cover w-full h-full" />
              </div>
              <div>
                <p className="font-semibold text-foreground">Ana Paula Ribeiro</p>
                <p className="text-muted-foreground text-sm">Florianópolis, SC · Cliente desde 2022</p>
              </div>
              <div className="ml-auto hidden md:block">
                <span className="text-xs text-accent font-medium bg-accent/10 px-3 py-1 rounded-full">Cliente Fiel ⭐</span>
              </div>
            </div>
          </div>
        </div>

        {/* Grid of testimonials */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials?.map((t, i) =>
          <div
            key={t?.name}
            className={`reveal reveal-delay-${i % 3 + 1} glass-card rounded-3xl p-6 shadow-warm-md hover:shadow-warm-lg transition-shadow duration-300`}>

              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {Array.from({ length: t?.rating })?.map((_, j) =>
              <Icon key={j} name="StarIcon" size={16} className="text-accent" variant="solid" />
              )}
              </div>

              <p className="text-foreground text-sm leading-relaxed mb-6">
                &ldquo;{t?.text}&rdquo;
              </p>

              <div className="flex items-center gap-3 pt-4 border-t border-border">
                <div className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0">
                  <AppImage
                  src={t?.avatar}
                  alt={`Foto de ${t?.name}, cliente satisfeita do Lilian Artesanato`}
                  width={40}
                  height={40}
                  className="object-cover w-full h-full" />

                </div>
                <div>
                  <p className="font-semibold text-foreground text-sm">{t?.name}</p>
                  <p className="text-muted-foreground text-xs">{t?.city}</p>
                </div>
                <div className="ml-auto">
                  <span className="text-[10px] text-accent font-medium">{t?.product}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>);

}