'use client';

import React, { useEffect, useRef } from 'react';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';

const stats = [
{ value: '500+', label: 'Clientes satisfeitas' },
{ value: '8 anos', label: 'De experiência artesanal' },
{ value: '100%', label: 'Feito à mão' },
{ value: '4.9★', label: 'Avaliação média' }];


export default function CraftStory() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) entry.target.classList.add('active');
        });
      },
      { threshold: 0.08 }
    );
    sectionRef?.current?.querySelectorAll('.reveal')?.forEach((el) => observer?.observe(el));
    return () => observer?.disconnect();
  }, []);

  return (
    <section className="py-16 md:py-24 px-4 md:px-6 bg-muted overflow-hidden" ref={sectionRef}>
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12 reveal">
          <span className="text-[11px] uppercase tracking-[0.3em] text-muted-foreground font-semibold mb-3 block">
            Quem está por trás de cada ponto
          </span>
          <h2 className="font-display text-section-title font-semibold text-foreground">
            Sobre a <span className="italic font-light text-accent">Lilian Artesanato</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-10 lg:gap-16 items-center">
          {/* Left: Photo — 2 cols */}
          <div className="reveal lg:col-span-2 relative">
            <div className="relative h-[420px] md:h-[580px] rounded-3xl overflow-hidden shadow-warm-xl">
              <AppImage
                src="/assets/images/WhatsApp_Image_2026-08-14_at_18.28.47-1787234116242.jpeg"
                alt="Lilian, artesã fundadora do Lilian Artesanato, com suas criações de bolsas de crochê feitas à mão"
                fill
                className="object-cover object-top"
                sizes="(max-width: 768px) 100vw, 40vw" />

              <div className="absolute inset-0 bg-gradient-to-t from-primary/40 via-transparent to-transparent" />

              {/* Name badge at bottom */}
              <div className="absolute bottom-4 left-4 right-4">
                <div className="glass-card px-5 py-3 rounded-2xl">
                  <p className="font-display font-bold text-foreground text-base">Lilian</p>
                  <p className="text-muted-foreground text-xs">Fundadora & Artesã</p>
                </div>
              </div>
            </div>

            {/* Floating badge */}
            <div className="absolute -top-4 -right-2 md:right-4 glass-card px-5 py-3 rounded-2xl shadow-warm-lg">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-accent/20 flex items-center justify-center">
                  <Icon name="HeartIcon" size={16} className="text-accent" variant="solid" />
                </div>
                <div>
                  <p className="font-bold text-foreground text-xs">Cada ponto, com amor</p>
                  <p className="text-muted-foreground text-[10px]">Artesanato genuíno</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Content — 3 cols */}
          <div className="lg:col-span-3 flex flex-col justify-between h-full gap-8">
            <div className="reveal">
              <p className="text-muted-foreground leading-relaxed text-base mb-4">
                Olá! Sou a <strong className="text-foreground">Lilian</strong>, artesã apaixonada pelo crochê há mais de 8 anos. Tudo começou como um hobby nas tardes livres e se transformou em uma missão: levar beleza, originalidade e carinho para as mãos de mulheres que valorizam o feito à mão.
              </p>
              <p className="text-muted-foreground leading-relaxed text-base mb-4">
                Cada bolsa que crio é única. Escolho pessoalmente os fios — priorizando qualidade, textura e cores que combinam com o estilo de vida moderno. Trabalho com técnicas tradicionais de crochê, adaptadas ao meu jeito especial de criar peças que são ao mesmo tempo funcionais e verdadeiras obras de arte.
              </p>
              <p className="text-muted-foreground leading-relaxed text-base">
                Aqui no <strong className="text-foreground">Lilian Artesanato</strong>, não produzimos em série. Cada encomenda é tratada com atenção individual, do primeiro ponto à entrega. Meu maior prazer é saber que minha arte está sendo usada e admirada por aí!
              </p>
            </div>

            {/* Stats grid */}
            <div className="reveal reveal-delay-2 grid grid-cols-2 gap-4">
              {stats?.map((stat, i) =>
              <div
                key={stat?.label}
                className="p-4 rounded-2xl bg-card border border-border"
                style={{ transitionDelay: `${i * 80}ms` }}>

                  <p className="font-display text-2xl font-bold text-foreground">{stat?.value}</p>
                  <p className="text-muted-foreground text-xs mt-1">{stat?.label}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>);

}