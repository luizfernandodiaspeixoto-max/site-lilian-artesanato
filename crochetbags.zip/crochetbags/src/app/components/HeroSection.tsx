'use client';

import React, { useEffect, useRef } from 'react';
import Link from 'next/link';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';

export default function HeroSection() {
  const parallaxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (parallaxRef?.current) {
        const scrollY = window.scrollY;
        parallaxRef.current.style.transform = `translateY(${scrollY * 0.08}px)`;
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center pt-28 pb-16 px-6 overflow-hidden">
      {/* Atmospheric blobs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 blob-accent rounded-full pointer-events-none" aria-hidden />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 blob-primary rounded-full pointer-events-none" aria-hidden />

      <div className="max-w-5xl w-full text-center relative z-10">
        {/* Eyebrow badge */}
        <div className="reveal inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-accent/30 bg-white/40 backdrop-blur-sm text-sm text-accent font-medium mb-8">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-accent" />
          </span>
          Feitas à mão com amor · Peças por Encomenda
        </div>

        <h1 className="reveal reveal-delay-1 font-display text-hero-xl font-semibold text-foreground mb-6">
          Lilian Artesanato,<br />
          <span className="italic font-light text-accent">única como você.</span>
        </h1>

        <p className="reveal reveal-delay-2 max-w-lg mx-auto text-lg md:text-xl text-muted-foreground leading-relaxed mb-10">
          Cada peça é crochê artesanal, tecida à mão com fios selecionados. Produtos feitos por encomenda — 50% de depósito para confirmar o pedido.
        </p>

        <div className="reveal reveal-delay-3 flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link href="/products" className="btn-primary group">
            Ver Coleção Completa
            <Icon name="ArrowRightIcon" size={18} className="group-hover:translate-x-1 transition-transform" />
          </Link>
          <a
            href="https://wa.me/5528999057982"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white font-semibold px-6 py-3 rounded-full transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
              <path d="M12 0C5.373 0 0 5.373 0 12c0 2.123.554 4.118 1.528 5.852L0 24l6.335-1.508A11.945 11.945 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.818 9.818 0 01-5.006-1.37l-.36-.213-3.76.895.952-3.653-.234-.374A9.818 9.818 0 1112 21.818z"/>
            </svg>
            (28) 99905-7982
          </a>
        </div>
      </div>

      {/* Hero Image */}
      <div className="reveal reveal-delay-4 w-full max-w-6xl mx-auto mt-16 h-[420px] md:h-[600px] rounded-[2.5rem] overflow-hidden relative border border-white/50 shadow-warm-xl">
        {/* Parallax layer */}
        <div
          ref={parallaxRef}
          className="parallax-layer absolute inset-0 w-full h-[115%] -top-[7%]">

          <AppImage
            src="/assets/images/WhatsApp_Image_2026-08-14_at_18.28.43_-_Copia-1787246473243.jpeg"
            alt="Bolsa Azul Royal com Alça de Madeira — peça artesanal única feita à mão em crochê"
            fill
            className="object-cover"
            priority
            sizes="(max-width: 768px) 100vw, 90vw" />

        </div>

        {/* Gradient scrim — dark at bottom for text legibility */}
        <div className="absolute inset-0 bg-gradient-to-t from-primary/70 via-primary/20 to-transparent z-10" />

        {/* Glass floating card */}
        <div className="absolute bottom-8 left-8 md:left-12 glass-card p-6 rounded-3xl shadow-warm-xl max-w-xs z-20 hidden md:block">
          <div className="flex justify-between items-start mb-4">
            <div>
              <p className="text-[10px] uppercase tracking-widest font-semibold mb-1" style={{color:'#6B4C3B'}}>Destaque da Semana</p>
              <h4 className="font-display text-lg font-semibold" style={{color:'#2C1810'}}>Bolsa Azul Royal</h4>
            </div>
            <span className="badge-handmade">Feita à Mão</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="font-display text-base font-semibold" style={{color:'#A0622A'}}>Sob encomenda</span>
            <Link href="/products" className="flex items-center gap-1 text-sm font-semibold hover:gap-2 transition-all" style={{color:'#A0622A'}}>
              Ver mais <Icon name="ArrowRightIcon" size={14} />
            </Link>
          </div>
        </div>

        {/* Stats pill */}
        <div className="absolute bottom-8 right-8 md:right-12 glass-card-dark px-5 py-3 rounded-full z-20 hidden md:flex items-center gap-3">
          <div className="text-center">
            <p className="text-white font-bold text-lg leading-none">500+</p>
            <p className="text-white/60 text-[10px] uppercase tracking-wider mt-0.5">Clientes</p>
          </div>
          <div className="w-px h-8 bg-white/20" />
          <div className="text-center">
            <p className="text-white font-bold text-lg leading-none">4.9★</p>
            <p className="text-white/60 text-[10px] uppercase tracking-wider mt-0.5">Avaliação</p>
          </div>
        </div>
      </div>
    </section>);

}