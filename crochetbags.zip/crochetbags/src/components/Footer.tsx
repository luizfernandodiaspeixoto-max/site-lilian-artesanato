'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import AppLogo from '@/components/ui/AppLogo';

interface ShippingOption {
  code: string;
  name: string;
  price: number;
  days: number;
}

function calcShipping(cep: string, weight: number): ShippingOption[] {
  const prefix = parseInt(cep.replace('-', '').substring(0, 2), 10);
  const isLocal = prefix === 29;
  const isSouth = prefix >= 80 && prefix <= 99;
  const isNorth = prefix >= 60 && prefix <= 79;

  let pacBase = 18.9;
  let sedexBase = 32.5;

  if (isLocal) { pacBase = 14.5; sedexBase = 24.9; }
  else if (isSouth) { pacBase = 22.9; sedexBase = 38.9; }
  else if (isNorth) { pacBase = 25.9; sedexBase = 42.9; }

  const weightFactor = weight > 1 ? 1 + (weight - 1) * 0.15 : 1;
  pacBase = Math.round(pacBase * weightFactor * 100) / 100;
  sedexBase = Math.round(sedexBase * weightFactor * 100) / 100;

  const pacDays = isLocal ? 3 : isSouth || isNorth ? 7 : 5;
  const sedexDays = isLocal ? 1 : isSouth || isNorth ? 3 : 2;

  return [
    { code: '04510', name: 'PAC', price: pacBase, days: pacDays },
    { code: '04014', name: 'SEDEX', price: sedexBase, days: sedexDays },
  ];
}

function formatBRL(value: number) {
  return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

export default function Footer() {
  const [cepInput, setCepInput] = useState('');
  const [weightInput, setWeightInput] = useState('');
  const [shippingOptions, setShippingOptions] = useState<ShippingOption[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const formatCep = (value: string) => {
    const digits = value.replace(/\D/g, '').slice(0, 8);
    if (digits.length > 5) return `${digits.slice(0, 5)}-${digits.slice(5)}`;
    return digits;
  };

  const handleCalc = () => {
    const digits = cepInput.replace('-', '');
    if (digits.length !== 8) {
      setError('Informe um CEP válido com 8 dígitos.');
      return;
    }
    const w = parseFloat(weightInput.replace(',', '.'));
    if (!weightInput || isNaN(w) || w <= 0) {
      setError('Informe o peso em kg (ex: 0.5).');
      return;
    }
    setError('');
    setLoading(true);
    setShippingOptions(null);
    setTimeout(() => {
      setShippingOptions(calcShipping(digits, w));
      setLoading(false);
    }, 800);
  };

  return (
    <footer className="border-t border-border">
      <div className="max-w-6xl mx-auto px-6 py-16">
        {/* Made-to-order banner */}
        <div className="mb-10 rounded-2xl bg-accent/10 border border-accent/20 px-6 py-5 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <span className="text-2xl">🧶</span>
            <div>
              <p className="font-semibold text-foreground text-sm">Produtos Feitos por Encomenda</p>
              <p className="text-muted-foreground text-sm mt-0.5">
                Todas as peças são produzidas sob encomenda. É necessário um depósito de <strong>50%</strong> do valor para confirmar o pedido.
              </p>
            </div>
          </div>
          <a
            href="https://wa.me/5528999057982"
            target="_blank"
            rel="noopener noreferrer"
            className="flex-shrink-0 inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white font-semibold text-sm px-5 py-2.5 rounded-full transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
              <path d="M12 0C5.373 0 0 5.373 0 12c0 2.123.554 4.118 1.528 5.852L0 24l6.335-1.508A11.945 11.945 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.818 9.818 0 01-5.006-1.37l-.36-.213-3.76.895.952-3.653-.234-.374A9.818 9.818 0 1112 21.818z"/>
            </svg>
            (28) 99905-7982
          </a>
        </div>

        {/* Freight Calculator */}
        <div className="mb-10 rounded-2xl bg-card border border-border px-6 py-6">
          <div className="flex items-center gap-2 mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5 text-accent">
              <path d="M1 3h15v13H1zM16 8h4l3 3v5h-7V8z"/>
              <circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/>
            </svg>
            <h3 className="font-display font-semibold text-foreground text-base">Calcular Frete (Correios)</h3>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 mb-3">
            <div className="flex-1">
              <label className="block text-xs font-semibold text-muted-foreground mb-1.5">CEP de destino</label>
              <input
                type="text"
                value={cepInput}
                onChange={(e) => {
                  setCepInput(formatCep(e.target.value));
                  setError('');
                  setShippingOptions(null);
                }}
                placeholder="00000-000"
                className="w-full px-4 py-2.5 rounded-xl border border-border bg-background text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:ring-2 focus:ring-accent/40 focus:border-accent transition-colors"
              />
            </div>
            <div className="sm:w-40">
              <label className="block text-xs font-semibold text-muted-foreground mb-1.5">Peso (kg)</label>
              <input
                type="text"
                value={weightInput}
                onChange={(e) => {
                  setWeightInput(e.target.value);
                  setError('');
                  setShippingOptions(null);
                }}
                placeholder="Ex: 0.5"
                className="w-full px-4 py-2.5 rounded-xl border border-border bg-background text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:ring-2 focus:ring-accent/40 focus:border-accent transition-colors"
              />
            </div>
            <div className="sm:self-end">
              <button
                onClick={handleCalc}
                disabled={loading}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-accent text-primary font-semibold text-sm hover:opacity-90 transition-opacity disabled:opacity-60 flex items-center justify-center gap-2"
              >
                {loading ? (
                  <svg className="animate-spin w-4 h-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/>
                  </svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4">
                    <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
                  </svg>
                )}
                Calcular
              </button>
            </div>
          </div>

          {error && (
            <p className="text-xs text-red-500 mb-3">{error}</p>
          )}

          {shippingOptions && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3">
              {shippingOptions.map((opt) => (
                <div key={opt.code} className="flex items-center justify-between bg-background border border-border rounded-xl px-4 py-3">
                  <div>
                    <p className="text-sm font-semibold text-foreground">{opt.name}</p>
                    <p className="text-xs text-muted-foreground">Até {opt.days} dias úteis</p>
                  </div>
                  <span className="font-display font-bold text-accent text-base">{formatBRL(opt.price)}</span>
                </div>
              ))}
              <p className="sm:col-span-2 text-xs text-muted-foreground mt-1">
                * Valores estimados. O frete final será confirmado no pedido via WhatsApp.
              </p>
            </div>
          )}
        </div>

        {/* Payment Methods */}
        <div className="mb-10 rounded-2xl bg-card border border-border px-6 py-6">
          <div className="flex items-center gap-2 mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5 text-accent">
              <rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/>
            </svg>
            <h3 className="font-display font-semibold text-foreground text-base">Formas de Pagamento</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* PIX */}
            <div className="flex items-start gap-3 bg-background border border-border rounded-xl px-4 py-3">
              <span className="text-xl mt-0.5">⚡</span>
              <div>
                <p className="text-sm font-semibold text-foreground">PIX</p>
                <p className="text-xs text-muted-foreground mt-0.5">Pagamento instantâneo, sem taxas adicionais.</p>
              </div>
            </div>
            {/* Transferência Bancária */}
            <div className="flex items-start gap-3 bg-background border border-border rounded-xl px-4 py-3">
              <span className="text-xl mt-0.5">🏦</span>
              <div>
                <p className="text-sm font-semibold text-foreground">Transferência Bancária</p>
                <p className="text-xs text-muted-foreground mt-0.5">TED/DOC direto para a conta, sem taxas adicionais.</p>
              </div>
            </div>
          </div>
          {/* Credit card note */}
          <div className="mt-3 flex items-start gap-2 rounded-xl bg-amber-50 border border-amber-200 px-4 py-3">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5">
              <path fillRule="evenodd" d="M9.401 3.003c1.155-2 4.043-2 5.197 0l7.355 12.748c1.154 1.998-.29 4.5-2.599 4.5H4.645c-2.309 0-3.752-2.502-2.598-4.5L9.4 3.003zM12 8.25a.75.75 0 01.75.75v3.75a.75.75 0 01-1.5 0V9a.75.75 0 01.75-.75zm0 8.25a.75.75 0 100-1.5.75.75 0 000 1.5z" clipRule="evenodd" />
            </svg>
            <p className="text-xs text-amber-700">
              <strong>Cartão de crédito parcelado:</strong> compras parceladas no cartão estão sujeitas ao acréscimo das taxas da operadora de cartão. Consulte as condições via WhatsApp.
            </p>
          </div>
        </div>

        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <Link href="/" className="flex items-center gap-2">
            <AppLogo size={32} />
            <span className="font-display font-semibold text-base text-foreground">Lilian Artesanato</span>
          </Link>

          <nav className="flex flex-wrap items-center justify-center gap-x-8 gap-y-3 text-sm font-medium text-muted-foreground">
            <Link href="/" className="hover:text-foreground transition-colors">Início</Link>
            <Link href="/products" className="hover:text-foreground transition-colors">Catálogo</Link>
            <a
              href="https://wa.me/5528999057982"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-foreground transition-colors text-green-600 font-semibold"
            >
              WhatsApp
            </a>
          </nav>

          <div className="flex flex-col items-center md:items-end gap-1">
            <p className="flex items-center gap-1.5 text-sm text-muted-foreground">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4 text-accent flex-shrink-0">
                <path fillRule="evenodd" d="M11.54 22.351l.07.04.028.016a.76.76 0 00.723 0l.028-.015.071-.041a16.975 16.975 0 001.144-.742 19.58 19.58 0 002.683-2.282c1.944-2.003 3.5-4.697 3.5-8.327a8 8 0 10-16 0c0 3.63 1.556 6.326 3.5 8.327a19.58 19.58 0 002.682 2.282 16.975 16.975 0 001.145.742zM12 13.5a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
              </svg>
              São José do Calçado – ES
            </p>
            <p className="text-sm text-muted-foreground">
              © 2026 Lilian Artesanato
            </p>
            <Link href="/admin/orders" className="text-xs text-muted-foreground/40 hover:text-muted-foreground transition-colors mt-1">
              Admin
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}