'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useChat } from '@/lib/hooks/useChat';

const WHATSAPP_NUMBER = '5528999057982';

const SYSTEM_PROMPT = `Você é a assistente virtual da Lilian Artesanato, uma loja especializada em bolsas e acessórios de crochê feitos à mão no Brasil.

Informações sobre a loja:
- Nome: Lilian Artesanato
- WhatsApp: (28) 99905-7982
- Todos os produtos são feitos por encomenda, artesanalmente
- Prazo de produção: 7 a 15 dias úteis após confirmação do pedido
- Frete via Correios (PAC e SEDEX) para todo o Brasil
- Pagamento: PIX, transferência bancária ou combinado via WhatsApp
- Para fazer pedidos, o cliente deve entrar em contato pelo WhatsApp

Produtos disponíveis (bolsas de crochê artesanais):
- Bolsa Azul Royal com Alça de Madeira — R$ 189
- Kit Cestinhas de Crochê Trio Candy — R$ 215 (promoção, era R$ 259)
- Bolsa Hobo Vinho com Detalhes em Couro — R$ 239
- Bolsa Bucket Verde Escuro com Corrente Prata — R$ 229
- Bolsa Azul Marinho com Painel de Palha — R$ 249
- Bolsa Hobo Cinza Grafite com Detalhes em Couro — R$ 259
- Bolsa Baguete Preta com Alça Trançada — R$ 219
- Bolsa Tote Areia com Textura em Relevo — R$ 235
- Bolsa Redonda Azul com Alça Caramelo e Tassel — R$ 269
- Destaque Editorial Exclusiva — R$ 299
- Bolsa Quadrada Granny Square com Alça de Bambu — R$ 245 (promoção, era R$ 289)
- E mais modelos disponíveis no catálogo

Sobre frete:
- PAC: mais econômico, prazo de 3 a 7 dias úteis dependendo da região
- SEDEX: mais rápido, prazo de 1 a 3 dias úteis
- O valor do frete varia conforme o CEP e o peso do produto
- Há um calculador de frete no rodapé do site

Sobre pedidos e acompanhamento:
- Ao fazer o pedido pelo WhatsApp, o cliente recebe um código único (ex: LIL-XXXXXXXX)
- O código pode ser usado para acompanhar o pedido na seção "Consultar Pedido" do site

Instruções de comportamento:
- Responda sempre em português brasileiro
- Seja simpática, acolhedora e profissional
- Para dúvidas complexas ou para fazer pedidos, sugira o WhatsApp
- Mantenha respostas concisas e diretas
- Se não souber algo específico, oriente o cliente a perguntar pelo WhatsApp`;

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

const QUICK_QUESTIONS = [
  'Qual o prazo de entrega?',
  'Como faço um pedido?',
  'Como calcular o frete?',
  'Como acompanhar meu pedido?',
];

export default function AIChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: 'Olá! 👋 Sou a assistente virtual da Lilian Artesanato. Posso te ajudar com dúvidas sobre produtos, prazos, frete e pedidos. Como posso te ajudar hoje?',
    },
  ]);
  const [hasNewMessage, setHasNewMessage] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const { response, isLoading, error, sendMessage } = useChat('OPEN_AI', 'gpt-4o-mini', false);

  useEffect(() => {
    if (error) {
      const isRateLimit =
        error.message?.includes('429') ||
        error.message?.toLowerCase().includes('rate limit') ||
        error.message?.toLowerCase().includes('credits');

      setMessages(prev => {
        const last = prev[prev.length - 1];
        const fallback = isRateLimit
          ? 'Estou temporariamente indisponível. Por favor, entre em contato pelo WhatsApp para atendimento imediato! 💬' :'Ops! Ocorreu um erro. Tente novamente ou fale conosco pelo WhatsApp.';
        if (last?.role === 'assistant' && last.content === '...') {
          return [...prev.slice(0, -1), { role: 'assistant', content: fallback }];
        }
        return [...prev, { role: 'assistant', content: fallback }];
      });
    }
  }, [error]);

  const lastResponseRef = useRef('');
  useEffect(() => {
    if (response && !isLoading && response !== lastResponseRef.current) {
      lastResponseRef.current = response;
      setMessages(prev => {
        const last = prev[prev.length - 1];
        if (last?.role === 'assistant' && last.content === '...') {
          return [...prev.slice(0, -1), { role: 'assistant', content: response }];
        }
        return prev;
      });
      if (!isOpen) setHasNewMessage(true);
    }
  }, [response, isLoading, isOpen]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (isOpen) {
      setHasNewMessage(false);
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen]);

  const handleSend = (text?: string) => {
    const messageText = text || input.trim();
    if (!messageText || isLoading) return;

    const userMessage: Message = { role: 'user', content: messageText };
    const updatedMessages = [...messages, userMessage];
    setMessages([...updatedMessages, { role: 'assistant', content: '...' }]);
    setInput('');

    const apiMessages = [
      { role: 'system' as const, content: SYSTEM_PROMPT },
      ...updatedMessages.map(m => ({ role: m.role as 'user' | 'assistant', content: m.content })),
    ];

    sendMessage(apiMessages, { max_completion_tokens: 500 });
  };

  const handleWhatsApp = () => {
    const lastUserMsg = [...messages].reverse().find(m => m.role === 'user');
    const text = lastUserMsg
      ? `Olá! Vim pelo chat do site e tenho uma dúvida: ${lastUserMsg.content}`
      : 'Olá! Vim pelo chat do site e gostaria de mais informações.';
    const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <>
      {/* Chat bubble button */}
      <button
        onClick={() => setIsOpen(prev => !prev)}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full bg-green-600 hover:bg-green-700 text-white shadow-lg flex items-center justify-center transition-all duration-200 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
        aria-label="Abrir chat de atendimento"
      >
        {isOpen ? (
          <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
          </svg>
        ) : (
          <svg xmlns="http://www.w3.org/2000/svg" className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
          </svg>
        )}
        {hasNewMessage && !isOpen && (
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full border-2 border-white" />
        )}
      </button>

      {/* Chat panel */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 z-50 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl flex flex-col overflow-hidden border border-gray-100" style={{ maxHeight: '520px' }}>
          {/* Header */}
          <div className="bg-green-600 px-4 py-3 flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
              <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 3.104v5.714a2.25 2.25 0 01-.659 1.591L5 14.5M9.75 3.104c-.251.023-.501.05-.75.082m.75-.082a24.301 24.301 0 014.5 0m0 0v5.714c0 .597.237 1.17.659 1.591L19.8 15.3M14.25 3.104c.251.023.501.05.75.082M19.8 15.3l-1.57.393A9.065 9.065 0 0112 15a9.065 9.065 0 00-6.23-.693L5 14.5m14.8.8l1.402 1.402c1 1 .03 2.798-1.414 2.798H4.213c-1.444 0-2.414-1.798-1.414-2.798L4 15.3" />
              </svg>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white font-semibold text-sm leading-tight">Assistente Lilian</p>
              <p className="text-green-100 text-xs">Atendimento online</p>
            </div>
            <button
              onClick={handleWhatsApp}
              className="flex items-center gap-1.5 bg-white/20 hover:bg-white/30 text-white text-xs font-medium px-2.5 py-1.5 rounded-full transition-colors"
              title="Falar no WhatsApp"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
              WhatsApp
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3 bg-gray-50" style={{ minHeight: '200px', maxHeight: '300px' }}>
            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div
                  className={`max-w-[80%] px-3 py-2 rounded-2xl text-sm leading-relaxed ${
                    msg.role === 'user' ?'bg-green-600 text-white rounded-br-sm' :'bg-white text-gray-800 shadow-sm border border-gray-100 rounded-bl-sm'
                  }`}
                >
                  {msg.content === '...' ? (
                    <span className="flex gap-1 items-center py-0.5">
                      <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                      <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                      <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                    </span>
                  ) : (
                    msg.content
                  )}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick questions (only show at start) */}
          {messages.length <= 1 && (
            <div className="px-4 py-2 bg-gray-50 border-t border-gray-100 flex flex-wrap gap-1.5">
              {QUICK_QUESTIONS.map(q => (
                <button
                  key={q}
                  onClick={() => handleSend(q)}
                  disabled={isLoading}
                  className="text-xs bg-white border border-green-200 text-green-700 hover:bg-green-50 px-2.5 py-1 rounded-full transition-colors disabled:opacity-50"
                >
                  {q}
                </button>
              ))}
            </div>
          )}

          {/* Input */}
          <div className="px-3 py-3 bg-white border-t border-gray-100 flex items-center gap-2">
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Digite sua dúvida..."
              disabled={isLoading}
              className="flex-1 text-sm bg-gray-100 rounded-full px-4 py-2 outline-none focus:ring-2 focus:ring-green-300 disabled:opacity-60 placeholder-gray-400"
            />
            <button
              onClick={() => handleSend()}
              disabled={isLoading || !input.trim()}
              className="w-9 h-9 rounded-full bg-green-600 hover:bg-green-700 disabled:bg-gray-300 text-white flex items-center justify-center transition-colors flex-shrink-0"
              aria-label="Enviar mensagem"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" />
              </svg>
            </button>
          </div>
        </div>
      )}
    </>
  );
}
